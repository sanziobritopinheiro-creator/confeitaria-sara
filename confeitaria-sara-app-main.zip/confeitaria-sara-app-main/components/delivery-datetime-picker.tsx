import { View, TouchableOpacity, Text, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";

interface DeliveryDateTimePickerProps {
  deliveryDate?: string;
  onDeliveryDateChange: (date: string) => void;
}

export function DeliveryDateTimePicker({
  deliveryDate,
  onDeliveryDateChange,
}: DeliveryDateTimePickerProps) {
  const [dateInput, setDateInput] = useState("");
  const [timeInput, setTimeInput] = useState("");
  const [showInputs, setShowInputs] = useState(false);

  useEffect(() => {
    if (deliveryDate) {
      const [date, time] = deliveryDate.split("T");
      setDateInput(formatDateForDisplay(date));
      setTimeInput(time?.substring(0, 5) || "");
    }
  }, [deliveryDate]);

  const formatDateForDisplay = (isoDate: string) => {
    const [year, month, day] = isoDate.split("-");
    return `${day}/${month}/${year}`;
  };

  const formatDeliveryDate = (isoString?: string) => {
    if (!isoString) return "Não definida";
    try {
      const date = new Date(isoString);
      if (isNaN(date.getTime())) return "Data inválida";
      return date.toLocaleString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch (e) {
      return "Data inválida";
    }
  };

  const validateAndSave = () => {
    if (!dateInput || !timeInput) {
      Alert.alert("Erro", "Por favor, preencha data e hora");
      return;
    }

    // Validar formato da data DD/MM/YYYY
    const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const dateMatch = dateInput.match(dateRegex);

    if (!dateMatch) {
      Alert.alert("Erro", "Data inválida. Use o formato DD/MM/YYYY");
      return;
    }

    const [, day, month, year] = dateMatch;
    const dayNum = parseInt(day);
    const monthNum = parseInt(month);

    if (monthNum < 1 || monthNum > 12) {
      Alert.alert("Erro", "Mês inválido (01-12)");
      return;
    }

    if (dayNum < 1 || dayNum > 31) {
      Alert.alert("Erro", "Dia inválido (01-31)");
      return;
    }

    // Validar formato da hora HH:mm
    const timeRegex = /^(\d{2}):(\d{2})$/;
    const timeMatch = timeInput.match(timeRegex);

    if (!timeMatch) {
      Alert.alert("Erro", "Hora inválida. Use o formato HH:mm");
      return;
    }

    const [, hours, minutes] = timeMatch;
    const hoursNum = parseInt(hours);
    const minutesNum = parseInt(minutes);

    if (hoursNum < 0 || hoursNum > 23) {
      Alert.alert("Erro", "Hora inválida (00-23)");
      return;
    }

    if (minutesNum < 0 || minutesNum > 59) {
      Alert.alert("Erro", "Minuto inválido (00-59)");
      return;
    }

    // Converter para ISO format
    const isoDate = `${year}-${month}-${day}`;
    const dateTime = `${isoDate}T${timeInput}:00`;

    onDeliveryDateChange(dateTime);
    setShowInputs(false);
  };

  return (
    <View className="gap-3">
      {!showInputs ? (
        <TouchableOpacity
          onPress={() => setShowInputs(true)}
          className="bg-surface border border-border rounded-lg p-4 active:opacity-70"
        >
          <Text className="text-xs text-muted mb-1">Entrega agendada para:</Text>
          <Text className="text-sm font-semibold text-foreground">
            {formatDeliveryDate(deliveryDate)}
          </Text>
          {deliveryDate && (
            <TouchableOpacity
              onPress={() => {
                onDeliveryDateChange("");
                setDateInput("");
                setTimeInput("");
              }}
              className="mt-2 py-1 active:opacity-70"
            >
              <Text className="text-xs text-error font-medium">Limpar data</Text>
            </TouchableOpacity>
          )}
        </TouchableOpacity>
      ) : (
        <View className="bg-surface border border-border rounded-lg p-4 gap-3">
          {/* Date Input */}
          <View className="gap-2">
            <Text className="text-xs font-semibold text-foreground">Data (DD/MM/YYYY)</Text>
            <TextInput
              value={dateInput}
              onChangeText={(text) => {
                // Formatar entrada automaticamente
                const cleaned = text.replace(/\D/g, "");
                let formatted = cleaned;

                if (cleaned.length >= 2) {
                  formatted = cleaned.slice(0, 2) + "/" + cleaned.slice(2);
                }
                if (cleaned.length >= 4) {
                  formatted = cleaned.slice(0, 2) + "/" + cleaned.slice(2, 4) + "/" + cleaned.slice(4, 8);
                }

                setDateInput(formatted);
              }}
              placeholder="DD/MM/YYYY"
              placeholderTextColor="#999"
              maxLength={10}
              keyboardType="numeric"
              className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
            />
          </View>

          {/* Time Input */}
          <View className="gap-2">
            <Text className="text-xs font-semibold text-foreground">Hora (HH:mm)</Text>
            <TextInput
              value={timeInput}
              onChangeText={(text) => {
                // Formatar entrada automaticamente
                const cleaned = text.replace(/\D/g, "");
                let formatted = cleaned;

                if (cleaned.length >= 2) {
                  formatted = cleaned.slice(0, 2) + ":" + cleaned.slice(2, 4);
                }

                setTimeInput(formatted);
              }}
              placeholder="HH:mm"
              placeholderTextColor="#999"
              maxLength={5}
              keyboardType="numeric"
              className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
            />
          </View>

          {/* Action Buttons */}
          <View className="flex-row gap-2 mt-2">
            <TouchableOpacity
              onPress={validateAndSave}
              className="flex-1 bg-primary rounded-lg p-3 active:opacity-80"
            >
              <Text className="text-center text-white font-semibold">Confirmar</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setShowInputs(false)}
              className="flex-1 bg-surface border border-border rounded-lg p-3 active:opacity-70"
            >
              <Text className="text-center text-foreground font-semibold">Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}
