import { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, Alert } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { GestureHandlerRootView } from "react-native-gesture-handler";

interface QRCodeScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export function QRCodeScanner({ onScan, onClose }: QRCodeScannerProps) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  useEffect(() => {
    if (!permission) {
      requestPermission();
    }
  }, [permission, requestPermission]);

  if (!permission) {
    return (
      <View className="flex-1 items-center justify-center bg-background">
        <Text className="text-foreground mb-4">Solicitando permissão de câmera...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View className="flex-1 items-center justify-center bg-background p-4 gap-4">
        <Text className="text-foreground text-center">
          Precisamos de acesso à câmera para ler QR codes
        </Text>
        <TouchableOpacity
          onPress={requestPermission}
          className="bg-primary rounded-lg px-6 py-3 active:opacity-80"
        >
          <Text className="text-white font-semibold">Permitir Câmera</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={onClose}
          className="bg-surface border border-border rounded-lg px-6 py-3 active:opacity-70"
        >
          <Text className="text-foreground font-semibold">Cancelar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleBarcodeScanned = ({ data }: { data: string }) => {
    if (!scanned) {
      setScanned(true);
      onScan(data);
    }
  };

  return (
    <GestureHandlerRootView className="flex-1">
      <View className="flex-1 bg-black">
        <CameraView
        style={{ flex: 1 }}
        facing="back"
        onBarcodeScanned={scanned ? undefined : handleBarcodeScanned}
        barcodeScannerSettings={{
          barcodeTypes: ["qr"],
        }}
      >
        {/* Overlay com instruções */}
        <View className="flex-1 items-center justify-center">
          <View className="w-64 h-64 border-2 border-white rounded-lg opacity-50" />
          <Text className="text-white text-center mt-8 text-lg">
            Aponte a câmera para o QR code
          </Text>
        </View>

        {/* Botões de controle */}
        <View className="absolute bottom-0 left-0 right-0 flex-row justify-center gap-4 p-4 bg-black bg-opacity-50">
          <TouchableOpacity
            onPress={() => setScanned(false)}
            className="bg-primary rounded-lg px-6 py-3 active:opacity-80"
          >
            <Text className="text-white font-semibold">Escanear Novamente</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={onClose}
            className="bg-red-500 rounded-lg px-6 py-3 active:opacity-80"
          >
            <Text className="text-white font-semibold">Cancelar</Text>
          </TouchableOpacity>
        </View>
        </CameraView>
      </View>
    </GestureHandlerRootView>
  );
}
