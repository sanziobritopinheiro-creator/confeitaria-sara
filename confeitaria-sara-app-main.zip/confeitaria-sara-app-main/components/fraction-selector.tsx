import { View, TouchableOpacity, Text } from "react-native";

interface FractionSelectorProps {
  fractions: number[];
  onFractionsChange: (fractions: number[]) => void;
  productName: string;
  pricePerHundred: number;
}

const AVAILABLE_FRACTIONS = [25, 50, 75, 100, 150];

export function FractionSelector({
  fractions,
  onFractionsChange,
  productName,
  pricePerHundred,
}: FractionSelectorProps) {
  const totalUnits = fractions.reduce((sum, f) => sum + f, 0);
  const totalPrice = (totalUnits / 100) * pricePerHundred;

  const handleAddFraction = (fraction: number) => {
    onFractionsChange([...fractions, fraction]);
  };

  const handleRemoveFraction = (index: number) => {
    const newFractions = fractions.filter((_, i) => i !== index);
    onFractionsChange(newFractions);
  };

  return (
    <View className="bg-surface border border-border rounded-lg p-4 gap-3">
      {/* Product Header */}
      <View className="gap-1">
        <Text className="text-sm font-semibold text-foreground">{productName}</Text>
        <Text className="text-xs text-muted">
          {totalUnits} unidades • R$ {totalPrice.toFixed(2)}
        </Text>
      </View>

      {/* Fraction Buttons */}
      <View className="flex-row flex-wrap gap-2">
        {AVAILABLE_FRACTIONS.map((fraction) => {
          const fractionPrice = (fraction / 100) * pricePerHundred;
          return (
            <TouchableOpacity
              key={fraction}
              onPress={() => handleAddFraction(fraction)}
              className="bg-primary rounded-lg px-3 py-2 active:opacity-70"
            >
              <Text className="text-white text-xs font-semibold">
                +{fraction}
              </Text>
              <Text className="text-white text-xs opacity-80">
                R$ {fractionPrice.toFixed(2)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Selected Fractions */}
      {fractions.length > 0 && (
        <View className="gap-2 mt-2 pt-3 border-t border-border">
          <Text className="text-xs font-medium text-muted">Frações Selecionadas:</Text>
          <View className="flex-row flex-wrap gap-2">
            {fractions.map((fraction, index) => {
              const fractionPrice = (fraction / 100) * pricePerHundred;
              return (
                <TouchableOpacity
                  key={index}
                  onPress={() => handleRemoveFraction(index)}
                  className="bg-background border border-error rounded-lg px-3 py-2 flex-row items-center gap-1 active:opacity-70"
                >
                  <Text className="text-foreground text-xs font-medium">{fraction}</Text>
                  <Text className="text-error text-xs">×</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      )}

      {/* Clear Button */}
      {fractions.length > 0 && (
        <TouchableOpacity
          onPress={() => onFractionsChange([])}
          className="bg-background border border-border rounded-lg p-2 active:opacity-70"
        >
          <Text className="text-center text-foreground text-xs font-medium">Limpar Frações</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
