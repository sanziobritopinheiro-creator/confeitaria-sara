import { View, TouchableOpacity, Text, ScrollView } from "react-native";
import { useState, useRef, useEffect } from "react";

interface TimePickerProps {
  selectedTime?: string;
  onTimeSelect: (time: string) => void;
}

export function TimePicker({ selectedTime, onTimeSelect }: TimePickerProps) {
  const [hours, setHours] = useState(selectedTime ? parseInt(selectedTime.split(":")[0]) : 8);
  const [minutes, setMinutes] = useState(selectedTime ? parseInt(selectedTime.split(":")[1]) : 0);

  const hoursRef = useRef<ScrollView>(null);
  const minutesRef = useRef<ScrollView>(null);

  const hoursList = Array.from({ length: 24 }, (_, i) => i);
  const minutesList = Array.from({ length: 60 }, (_, i) => i);

  useEffect(() => {
    const timeString = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
    onTimeSelect(timeString);
  }, [hours, minutes]);

  const handleHourScroll = (event: any) => {
    const contentOffsetY = event.nativeEvent.contentOffset.y;
    const index = Math.round(contentOffsetY / 40);
    setHours(Math.max(0, Math.min(23, index)));
  };

  const handleMinuteScroll = (event: any) => {
    const contentOffsetY = event.nativeEvent.contentOffset.y;
    const index = Math.round(contentOffsetY / 40);
    setMinutes(Math.max(0, Math.min(59, index)));
  };

  return (
    <View className="bg-surface border border-border rounded-lg p-4 gap-4">
      <Text className="text-sm font-semibold text-foreground text-center">Selecione a Hora</Text>

      {/* Time Picker Display */}
      <View className="flex-row justify-center items-center gap-2 bg-background rounded-lg p-4">
        {/* Hours */}
        <View className="w-16 h-32 bg-surface border border-border rounded-lg overflow-hidden">
          <ScrollView
            ref={hoursRef}
            scrollEventThrottle={16}
            onScroll={handleHourScroll}
            snapToInterval={40}
            decelerationRate="fast"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingVertical: 64 }}
          >
            {hoursList.map((hour) => (
              <View key={hour} className="h-10 items-center justify-center">
                <Text
                  className={`text-lg font-semibold ${
                    hour === hours ? "text-primary" : "text-muted"
                  }`}
                >
                  {String(hour).padStart(2, "0")}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Separator */}
        <Text className="text-2xl font-bold text-foreground">:</Text>

        {/* Minutes */}
        <View className="w-16 h-32 bg-surface border border-border rounded-lg overflow-hidden">
          <ScrollView
            ref={minutesRef}
            scrollEventThrottle={16}
            onScroll={handleMinuteScroll}
            snapToInterval={40}
            decelerationRate="fast"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingVertical: 64 }}
          >
            {minutesList.map((minute) => (
              <View key={minute} className="h-10 items-center justify-center">
                <Text
                  className={`text-lg font-semibold ${
                    minute === minutes ? "text-primary" : "text-muted"
                  }`}
                >
                  {String(minute).padStart(2, "0")}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>

      {/* Quick Selection Buttons */}
      <View className="gap-2">
        <Text className="text-xs font-semibold text-muted">Horários Comuns</Text>
        <View className="flex-row gap-2 flex-wrap">
          {["08:00", "10:00", "12:00", "14:00", "16:00", "18:00"].map((time) => (
            <TouchableOpacity
              key={time}
              onPress={() => {
                const [h, m] = time.split(":").map(Number);
                setHours(h);
                setMinutes(m);
              }}
              className="bg-background border border-border rounded-lg px-3 py-2 active:opacity-70"
            >
              <Text className="text-xs font-semibold text-foreground">{time}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );
}
