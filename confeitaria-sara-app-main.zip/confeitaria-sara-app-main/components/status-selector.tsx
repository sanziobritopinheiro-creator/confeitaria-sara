import { View, TouchableOpacity, Text } from "react-native";

type OrderStatus = "open" | "paid" | "pending_payment";

interface StatusSelectorProps {
  status: OrderStatus;
  onStatusChange: (status: OrderStatus) => void;
}

const STATUS_OPTIONS: { value: OrderStatus; label: string; color: string }[] = [
  { value: "open", label: "Pedido Aberto", color: "bg-warning" },
  { value: "paid", label: "Concluído/Pago", color: "bg-success" },
  { value: "pending_payment", label: "Concluído/Devendo", color: "bg-error" },
];

export function StatusSelector({ status, onStatusChange }: StatusSelectorProps) {
  const currentStatus = STATUS_OPTIONS.find((s) => s.value === status);

  return (
    <View className="gap-2">
      <View className="flex-row gap-2 flex-wrap">
        {STATUS_OPTIONS.map((option) => (
          <TouchableOpacity
            key={option.value}
            onPress={() => onStatusChange(option.value)}
            className={`flex-1 min-w-[30%] rounded-lg p-2 active:opacity-70 ${
              status === option.value ? option.color : "bg-surface border border-border"
            }`}
          >
            <Text
              className={`text-xs font-semibold text-center ${
                status === option.value ? "text-white" : "text-foreground"
              }`}
            >
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

export function getStatusColor(status: OrderStatus): string {
  const statusOption = STATUS_OPTIONS.find((s) => s.value === status);
  return statusOption?.color || "bg-surface";
}

export function getStatusLabel(status: OrderStatus): string {
  const statusOption = STATUS_OPTIONS.find((s) => s.value === status);
  return statusOption?.label || status;
}
