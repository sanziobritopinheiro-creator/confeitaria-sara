import { View, TouchableOpacity, Text, ScrollView } from "react-native";
import { useState, useMemo } from "react";

interface CalendarPickerProps {
  selectedDate?: string;
  onDateSelect: (date: string) => void;
}

export function CalendarPicker({ selectedDate, onDateSelect }: CalendarPickerProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentMonth);
  const firstDay = getFirstDayOfMonth(currentMonth);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const selectedDateObj = selectedDate ? new Date(selectedDate) : null;
  const isSelectedMonth =
    selectedDateObj &&
    selectedDateObj.getMonth() === currentMonth.getMonth() &&
    selectedDateObj.getFullYear() === currentMonth.getFullYear();

  const handleSelectDate = (day: number) => {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    const isoDate = date.toISOString().split("T")[0];
    onDateSelect(isoDate);
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const monthName = currentMonth.toLocaleString("pt-BR", { month: "long", year: "numeric" });
  const dayLabels = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];

  return (
    <View className="bg-surface border border-border rounded-lg p-4 gap-4">
      {/* Month Navigation */}
      <View className="flex-row justify-between items-center">
        <TouchableOpacity onPress={handlePrevMonth} className="p-2 active:opacity-70">
          <Text className="text-lg font-semibold text-primary">←</Text>
        </TouchableOpacity>
        <Text className="text-sm font-semibold text-foreground capitalize">{monthName}</Text>
        <TouchableOpacity onPress={handleNextMonth} className="p-2 active:opacity-70">
          <Text className="text-lg font-semibold text-primary">→</Text>
        </TouchableOpacity>
      </View>

      {/* Day Labels */}
      <View className="flex-row justify-between">
        {dayLabels.map((label) => (
          <Text key={label} className="text-xs font-semibold text-muted w-1/7 text-center">
            {label}
          </Text>
        ))}
      </View>

      {/* Calendar Grid */}
      <View className="gap-2">
        {Array.from({ length: Math.ceil((daysInMonth + firstDay) / 7) }).map((_, weekIndex) => (
          <View key={weekIndex} className="flex-row justify-between">
            {Array.from({ length: 7 }).map((_, dayIndex) => {
              const dayNumber = weekIndex * 7 + dayIndex - firstDay + 1;
              const isValidDay = dayNumber > 0 && dayNumber <= daysInMonth;
              const isSelected =
                isSelectedMonth && selectedDateObj?.getDate() === dayNumber;

              return (
                <TouchableOpacity
                  key={dayIndex}
                  onPress={() => isValidDay && handleSelectDate(dayNumber)}
                  disabled={!isValidDay}
                  className={`w-1/7 aspect-square rounded-lg items-center justify-center ${
                    isSelected
                      ? "bg-primary"
                      : isValidDay
                        ? "bg-background border border-border"
                        : "bg-transparent"
                  } active:opacity-70`}
                >
                  <Text
                    className={`text-sm font-medium ${
                      isSelected ? "text-white" : isValidDay ? "text-foreground" : "text-muted"
                    }`}
                  >
                    {isValidDay ? dayNumber : ""}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </View>
    </View>
  );
}
