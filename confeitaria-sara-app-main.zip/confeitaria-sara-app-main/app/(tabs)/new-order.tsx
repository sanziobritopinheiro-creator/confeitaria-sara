import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert, ActivityIndicator, Linking } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { WhatsAppService } from "@/lib/whatsapp-service";
import { NotificationService } from "@/lib/notification-service";
import { useState } from "react";
import { Order, OrderItem } from "@/types";
import { FractionSelector } from "@/components/fraction-selector";
import { DeliveryDateTimePicker } from "@/components/delivery-datetime-picker";

interface ProductFractions {
  [productId: string]: number[];
}

export default function NewOrderScreen() {
  const { products, addOrder, isLoading } = useData();
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [productFractions, setProductFractions] = useState<ProductFractions>({});
  const [notes, setNotes] = useState("");
  const [expandedProduct, setExpandedProduct] = useState<string | null>(null);
  const [deliveryDate, setDeliveryDate] = useState<string | undefined>();
  const [sendWhatsApp, setSendWhatsApp] = useState(false);

  const handleFractionsChange = (productId: string, fractions: number[]) => {
    setProductFractions({
      ...productFractions,
      [productId]: fractions,
    });
  };

  const calculateTotal = () => {
    let total = 0;
    Object.entries(productFractions).forEach(([productId, fractions]) => {
      if (fractions.length > 0) {
        const product = products.find((p) => p.id === productId);
        if (product) {
          const totalUnits = fractions.reduce((sum, f) => sum + f, 0);
          total += (totalUnits / 100) * product.price;
        }
      }
    });
    return total;
  };

  const handleSaveOrder = async () => {
    if (!clientName.trim()) {
      Alert.alert("Erro", "Por favor, insira o nome do cliente");
      return;
    }

    const hasProducts = Object.values(productFractions).some((fractions) => fractions.length > 0);
    if (!hasProducts) {
      Alert.alert("Erro", "Por favor, adicione pelo menos um produto");
      return;
    }

    const items: OrderItem[] = [];
    Object.entries(productFractions).forEach(([productId, fractions]) => {
      if (fractions.length > 0) {
        const product = products.find((p) => p.id === productId);
        if (product) {
          const totalUnits = fractions.reduce((sum, f) => sum + f, 0);
          const subtotal = (totalUnits / 100) * product.price;
          items.push({
            productId,
            productName: product.name,
            quantity: totalUnits,
            price: product.price,
            subtotal,
            fractions,
          });
        }
      }
    });

    const total = calculateTotal();

    const newOrder: Order = {
      id: Date.now().toString(),
      clientName,
      clientPhone: clientPhone || undefined,
      date: new Date().toISOString(),
      deliveryDate,
      items,
      total,
      status: "open",
      notes: notes || undefined,
    };

    try {
      await addOrder(newOrder);
      
      // Agendar notificação de confirmação
      await NotificationService.scheduleOrderConfirmation(newOrder);
      
      // Agendar lembretes de entrega se houver data
      if (deliveryDate) {
        await NotificationService.scheduleDeliveryReminder(newOrder);
      }
      
      // Enviar WhatsApp se solicitado
      if (sendWhatsApp && clientPhone) {
        if (!WhatsAppService.isValidPhoneNumber(clientPhone)) {
          Alert.alert("Aviso", "Número de WhatsApp inválido. Pedido salvo, mas mensagem não foi enviada.");
        } else {
          const sent = await WhatsAppService.sendOrderConfirmation(newOrder);
          if (!sent) {
            Alert.alert("Aviso", "Pedido salvo, mas não foi possível enviar a mensagem WhatsApp.");
          }
        }
      }
      
      Alert.alert("Sucesso", "Pedido registrado com sucesso!");
      setClientName("");
      setClientPhone("");
      setProductFractions({});
      setNotes("");
      setExpandedProduct(null);
      setDeliveryDate(undefined);
      setSendWhatsApp(false);
    } catch (error) {
      Alert.alert("Erro", "Não foi possível salvar o pedido");
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  const total = calculateTotal();
  const hasProducts = Object.values(productFractions).some((fractions) => fractions.length > 0);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Novo Pedido</Text>
            <Text className="text-sm text-muted">Selecione as frações de cada produto</Text>
          </View>

          {/* Client Name Input */}
          <View className="gap-2">
            <Text className="text-sm font-medium text-foreground">Nome do Cliente</Text>
            <TextInput
              placeholder="Digite o nome do cliente"
              value={clientName}
              onChangeText={setClientName}
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor="#999"
            />
          </View>

          {/* Client Phone Input */}
          <View className="gap-2">
            <Text className="text-sm font-medium text-foreground">WhatsApp do Cliente (opcional)</Text>
            <TextInput
              placeholder="(33) 99931-5860 ou 33999315860"
              value={clientPhone}
              onChangeText={setClientPhone}
              keyboardType="phone-pad"
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor="#999"
            />
            {clientPhone && !WhatsAppService.isValidPhoneNumber(clientPhone) && (
              <Text className="text-xs text-error">Número de telefone inválido</Text>
            )}
          </View>

          {/* Send WhatsApp Checkbox */}
          {clientPhone && WhatsAppService.isValidPhoneNumber(clientPhone) && (
            <TouchableOpacity
              onPress={() => setSendWhatsApp(!sendWhatsApp)}
              className="flex-row items-center gap-3 bg-surface border border-border rounded-lg p-3 active:opacity-70"
            >
              <View
                className={`w-5 h-5 rounded border-2 items-center justify-center ${
                  sendWhatsApp ? "bg-primary border-primary" : "border-border"
                }`}
              >
                {sendWhatsApp && <Text className="text-white font-bold">✓</Text>}
              </View>
              <Text className="text-sm text-foreground">Enviar confirmação via WhatsApp</Text>
            </TouchableOpacity>
          )}


          {/* Products Section */}
          <View className="gap-3">
            <Text className="text-sm font-medium text-foreground">Produtos</Text>

            {/* Doces */}
            <View className="gap-2">
              <Text className="text-xs font-semibold text-muted uppercase">Doces</Text>
              <View className="gap-2">
                {products
                  .filter((p) => p.category === "doces")
                  .map((product) => (
                    <View key={product.id}>
                      <TouchableOpacity
                        onPress={() =>
                          setExpandedProduct(expandedProduct === product.id ? null : product.id)
                        }
                        className="bg-surface border border-border rounded-lg p-4 active:opacity-70"
                      >
                        <View className="flex-row justify-between items-center">
                          <View className="flex-1">
                            <Text className="text-sm font-medium text-foreground">
                              {product.name}
                            </Text>
                            <Text className="text-xs text-muted mt-1">
                              R$ {product.price.toFixed(2)} por 100 uni
                            </Text>
                          </View>
                          <View className="items-end">
                            {(productFractions[product.id]?.length ?? 0) > 0 && (
                              <Text className="text-sm font-bold text-primary">
                                {productFractions[product.id].reduce((a, b) => a + b, 0)} uni
                              </Text>
                            )}
                            <Text className="text-xs text-muted">
                              {expandedProduct === product.id ? "▼" : "▶"}
                            </Text>
                          </View>
                        </View>
                      </TouchableOpacity>

                      {expandedProduct === product.id && (
                        <View className="mt-2">
                          <FractionSelector
                            fractions={productFractions[product.id] ?? []}
                            onFractionsChange={(fractions) =>
                              handleFractionsChange(product.id, fractions)
                            }
                            productName={product.name}
                            pricePerHundred={product.price}
                          />
                        </View>
                      )}
                    </View>
                  ))}
              </View>
            </View>

            {/* Salgados */}
            <View className="gap-2">
              <Text className="text-xs font-semibold text-muted uppercase">Salgados</Text>
              <View className="gap-2">
                {products
                  .filter((p) => p.category === "salgados")
                  .map((product) => (
                    <View key={product.id}>
                      <TouchableOpacity
                        onPress={() =>
                          setExpandedProduct(expandedProduct === product.id ? null : product.id)
                        }
                        className="bg-surface border border-border rounded-lg p-4 active:opacity-70"
                      >
                        <View className="flex-row justify-between items-center">
                          <View className="flex-1">
                            <Text className="text-sm font-medium text-foreground">
                              {product.name}
                            </Text>
                            <Text className="text-xs text-muted mt-1">
                              R$ {product.price.toFixed(2)} por 100 uni
                            </Text>
                          </View>
                          <View className="items-end">
                            {(productFractions[product.id]?.length ?? 0) > 0 && (
                              <Text className="text-sm font-bold text-primary">
                                {productFractions[product.id].reduce((a, b) => a + b, 0)} uni
                              </Text>
                            )}
                            <Text className="text-xs text-muted">
                              {expandedProduct === product.id ? "▼" : "▶"}
                            </Text>
                          </View>
                        </View>
                      </TouchableOpacity>

                      {expandedProduct === product.id && (
                        <View className="mt-2">
                          <FractionSelector
                            fractions={productFractions[product.id] ?? []}
                            onFractionsChange={(fractions) =>
                              handleFractionsChange(product.id, fractions)
                            }
                            productName={product.name}
                            pricePerHundred={product.price}
                          />
                        </View>
                      )}
                    </View>
                  ))}
              </View>
            </View>
          </View>

          {/* Delivery Date and Time */}
          <DeliveryDateTimePicker
            deliveryDate={deliveryDate}
            onDeliveryDateChange={setDeliveryDate}
          />

          {/* Notes */}
          <View className="gap-2">
            <Text className="text-sm font-medium text-foreground">Observações (opcional)</Text>
            <TextInput
              placeholder="Adicione observações sobre o pedido"
              value={notes}
              onChangeText={setNotes}
              multiline
              numberOfLines={3}
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              placeholderTextColor="#999"
              textAlignVertical="top"
            />
          </View>

          {/* Total and Submit */}
          <View className="gap-3 mt-4">
            <View className="bg-surface rounded-lg border border-border p-4">
              <Text className="text-xs text-muted mb-1">Total do Pedido</Text>
              <Text className="text-3xl font-bold text-primary">R$ {total.toFixed(2)}</Text>
            </View>

            <TouchableOpacity
              onPress={handleSaveOrder}
              disabled={!hasProducts || !clientName.trim()}
              className="bg-primary rounded-lg p-4 active:opacity-80 disabled:opacity-50"
            >
              <Text className="text-center text-white font-semibold">Salvar Pedido</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
