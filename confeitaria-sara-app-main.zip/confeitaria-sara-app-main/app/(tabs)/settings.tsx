import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface BusinessInfo {
  name: string;
  phone: string;
  address: string;
  instagram: string;
}

export default function SettingsScreen() {
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>({
    name: "Confeitaria da Sara",
    phone: "(33) 99931-5860",
    address: "Rua Belo Horizonte, 157B - Jequitinhonha-MG",
    instagram: "@confeitariasarabrito",
  });

  const [isEditing, setIsEditing] = useState(false);
  const [tempInfo, setTempInfo] = useState<BusinessInfo>(businessInfo);

  // Carregar informações do AsyncStorage ao iniciar
  useEffect(() => {
    loadBusinessInfo();
  }, []);

  const loadBusinessInfo = async () => {
    try {
      const stored = await AsyncStorage.getItem("businessInfo");
      if (stored) {
        const info = JSON.parse(stored);
        setBusinessInfo(info);
        setTempInfo(info);
      }
    } catch (error) {
      console.error("Erro ao carregar informações:", error);
    }
  };

  const handleSaveInfo = async () => {
    try {
      await AsyncStorage.setItem("businessInfo", JSON.stringify(tempInfo));
      setBusinessInfo(tempInfo);
      setIsEditing(false);
      Alert.alert("Sucesso", "Informações atualizadas com sucesso");
    } catch (error) {
      Alert.alert("Erro", "Não foi possível salvar as informações");
    }
  };

  const handleCancel = () => {
    setTempInfo(businessInfo);
    setIsEditing(false);
  };

  const handleClearAllData = () => {
    Alert.alert("Atenção", "Tem certeza que deseja limpar todos os dados? Esta ação não pode ser desfeita.", [
      { text: "Cancelar", onPress: () => {} },
      {
        text: "Limpar",
        onPress: async () => {
          try {
            await AsyncStorage.removeItem("orders");
            Alert.alert("Sucesso", "Todos os dados foram limpos");
          } catch (error) {
            Alert.alert("Erro", "Não foi possível limpar os dados");
          }
        },
        style: "destructive",
      },
    ]);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Configurações</Text>
            <Text className="text-sm text-muted">Gerencie as informações da sua confeitaria</Text>
          </View>

          {/* Business Info Section */}
          <View className="gap-3">
            <View className="flex-row justify-between items-center">
              <Text className="text-lg font-semibold text-foreground">Informações da Confeitaria</Text>
              {!isEditing && (
                <TouchableOpacity onPress={() => setIsEditing(true)} className="active:opacity-70">
                  <Text className="text-primary font-medium text-sm">Editar</Text>
                </TouchableOpacity>
              )}
            </View>

            {isEditing ? (
              <View className="gap-3 bg-surface border border-border rounded-lg p-4">
                {/* Name Input */}
                <View className="gap-2">
                  <Text className="text-xs font-medium text-muted">Nome da Confeitaria</Text>
                  <TextInput
                    value={tempInfo.name}
                    onChangeText={(text) => setTempInfo({ ...tempInfo, name: text })}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                    placeholderTextColor="#999"
                  />
                </View>

                {/* Phone Input */}
                <View className="gap-2">
                  <Text className="text-xs font-medium text-muted">Telefone</Text>
                  <TextInput
                    value={tempInfo.phone}
                    onChangeText={(text) => setTempInfo({ ...tempInfo, phone: text })}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                    placeholderTextColor="#999"
                  />
                </View>

                {/* Address Input */}
                <View className="gap-2">
                  <Text className="text-xs font-medium text-muted">Endereço</Text>
                  <TextInput
                    value={tempInfo.address}
                    onChangeText={(text) => setTempInfo({ ...tempInfo, address: text })}
                    multiline
                    numberOfLines={2}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                    placeholderTextColor="#999"
                    textAlignVertical="top"
                  />
                </View>

                {/* Instagram Input */}
                <View className="gap-2">
                  <Text className="text-xs font-medium text-muted">Instagram</Text>
                  <TextInput
                    value={tempInfo.instagram}
                    onChangeText={(text) => setTempInfo({ ...tempInfo, instagram: text })}
                    className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                    placeholderTextColor="#999"
                  />
                </View>

                {/* Action Buttons */}
                <View className="flex-row gap-2 mt-2">
                  <TouchableOpacity
                    onPress={handleSaveInfo}
                    className="flex-1 bg-primary rounded-lg p-3 active:opacity-80"
                  >
                    <Text className="text-center text-white font-semibold text-sm">Salvar</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={handleCancel}
                    className="flex-1 bg-surface border border-border rounded-lg p-3 active:opacity-70"
                  >
                    <Text className="text-center text-foreground font-semibold text-sm">Cancelar</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <View className="bg-surface border border-border rounded-lg p-4 gap-4">
                <View>
                  <Text className="text-xs font-medium text-muted mb-1">Nome</Text>
                  <Text className="text-sm text-foreground">{businessInfo.name}</Text>
                </View>

                <View>
                  <Text className="text-xs font-medium text-muted mb-1">Telefone</Text>
                  <Text className="text-sm text-foreground">{businessInfo.phone}</Text>
                </View>

                <View>
                  <Text className="text-xs font-medium text-muted mb-1">Endereço</Text>
                  <Text className="text-sm text-foreground">{businessInfo.address}</Text>
                </View>

                <View>
                  <Text className="text-xs font-medium text-muted mb-1">Instagram</Text>
                  <Text className="text-sm text-foreground">{businessInfo.instagram}</Text>
                </View>
              </View>
            )}
          </View>

          {/* About Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Sobre</Text>
            <View className="bg-surface border border-border rounded-lg p-4 gap-3">
              <View>
                <Text className="text-xs font-medium text-muted mb-1">Versão do App</Text>
                <Text className="text-sm text-foreground">1.0.0</Text>
              </View>

              <View>
                <Text className="text-xs font-medium text-muted mb-1">Desenvolvido por</Text>
                <Text className="text-sm text-foreground">Manus</Text>
              </View>
            </View>
          </View>

          {/* Danger Zone */}
          <View className="gap-3 mt-4">
            <Text className="text-lg font-semibold text-error">Zona de Perigo</Text>
            <TouchableOpacity
              onPress={handleClearAllData}
              className="bg-error rounded-lg p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-semibold">Limpar Todos os Dados</Text>
            </TouchableOpacity>
            <Text className="text-xs text-muted text-center">
              Esta ação irá deletar todos os pedidos e não pode ser desfeita
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
