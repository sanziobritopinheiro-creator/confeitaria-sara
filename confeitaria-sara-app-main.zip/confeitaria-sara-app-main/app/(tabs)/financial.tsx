import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, Alert, Share } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useMemo, useState } from "react";
import { generateMonthlyReportPDF } from "@/lib/pdf-generator";
import * as FileSystem from "expo-file-system/legacy";

export default function FinancialScreen() {
  const { getFinancialSummary, getOrdersByMonth, getExpensesByMonth, isLoading } = useData();
  const [generatingReport, setGeneratingReport] = useState(false);

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const financialData = useMemo(
    () => getFinancialSummary(currentMonth, currentYear),
    [currentMonth, currentYear, getFinancialSummary]
  );

  const orders = useMemo(
    () => getOrdersByMonth(currentMonth, currentYear),
    [currentMonth, currentYear, getOrdersByMonth]
  );

  const expenses = useMemo(
    () => getExpensesByMonth(currentMonth, currentYear),
    [currentMonth, currentYear, getExpensesByMonth]
  );

  const handleGenerateReport = async () => {
    try {
      setGeneratingReport(true);

      const reportData = {
        month: currentMonth,
        year: currentYear,
        orders,
        expenses,
        businessName: "Confeitaria da Sara",
        businessPhone: "(33) 99931-5860",
        businessAddress: "Rua Belo Horizonte, 157B - Jequitinhonha-MG",
      };

      const result = await generateMonthlyReportPDF(reportData);

      Alert.alert(
        "Relatório Gerado",
        `Arquivo: ${result.fileName}\n\nDeseja compartilhar o relatório?`,
        [
          { text: "Cancelar", onPress: () => {} },
          {
            text: "Compartilhar",
            onPress: async () => {
              try {
                await Share.share({
                  url: result.filePath,
                  title: `Relatório - ${reportData.businessName}`,
                  message: `Relatório de vendas e despesas de ${new Date(currentYear, currentMonth).toLocaleString(
                    "pt-BR",
                    { month: "long", year: "numeric" }
                  )}`,
                });
              } catch (error) {
                Alert.alert("Erro", "Não foi possível compartilhar o relatório");
              }
            },
          },
        ]
      );
    } catch (error) {
      Alert.alert("Erro", "Não foi possível gerar o relatório");
      console.error(error);
    } finally {
      setGeneratingReport(false);
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  const profitColor = financialData.profit >= 0 ? "text-green-600" : "text-red-600";
  const profitBgColor = financialData.profit >= 0 ? "bg-green-50" : "bg-red-50";

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Financeiro</Text>
            <Text className="text-base text-muted">
              {financialData.month} de {financialData.year}
            </Text>
          </View>

          {/* Profit Card */}
          <View className={`rounded-2xl p-6 ${profitBgColor}`}>
            <Text className={`text-sm font-semibold mb-1 ${profitColor}`}>Lucro/Prejuízo</Text>
            <Text className={`text-4xl font-bold ${profitColor}`}>
              R$ {financialData.profit.toFixed(2)}
            </Text>
            <Text className={`text-sm font-semibold mt-2 ${profitColor}`}>
              Margem: {financialData.profitMargin.toFixed(1)}%
            </Text>
          </View>

          {/* Financial Summary Cards */}
          <View className="grid grid-cols-2 gap-4">
            <View className="bg-green-50 rounded-2xl p-4 border border-green-200">
              <Text className="text-xs text-green-600 font-semibold mb-2">Receita Total</Text>
              <Text className="text-2xl font-bold text-green-600">
                R$ {financialData.totalRevenue.toFixed(2)}
              </Text>
              <Text className="text-xs text-green-500 mt-1">{orders.length} pedidos</Text>
            </View>

            <View className="bg-red-50 rounded-2xl p-4 border border-red-200">
              <Text className="text-xs text-red-600 font-semibold mb-2">Despesa Total</Text>
              <Text className="text-2xl font-bold text-red-600">
                R$ {financialData.totalExpenses.toFixed(2)}
              </Text>
              <Text className="text-xs text-red-500 mt-1">{expenses.length} registros</Text>
            </View>
          </View>

          {/* Generate Report Button */}
          <TouchableOpacity
            onPress={handleGenerateReport}
            disabled={generatingReport}
            className="bg-primary rounded-2xl p-4 active:opacity-80 flex-row items-center justify-center gap-2"
          >
            {generatingReport ? (
              <>
                <ActivityIndicator size="small" color="white" />
                <Text className="text-white font-semibold">Gerando Relatório...</Text>
              </>
            ) : (
              <>
                <Text className="text-xl">📄</Text>
                <Text className="text-white font-semibold">Gerar Relatório PDF</Text>
              </>
            )}
          </TouchableOpacity>

          {/* Order Status Summary */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Status de Pedidos</Text>
            <View className="bg-surface border border-border rounded-2xl overflow-hidden">
              {/* Open Orders */}
              <View className="p-4 border-b border-border flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-medium text-foreground">Pedido Aberto</Text>
                  <Text className="text-xs text-muted mt-1">
                    {orders.filter((o) => o.status === "open").length} pedidos
                  </Text>
                </View>
                <Text className="text-lg font-bold text-yellow-600">
                  R$ {orders
                    .filter((o) => o.status === "open")
                    .reduce((sum, o) => sum + o.total, 0)
                    .toFixed(2)}
                </Text>
              </View>

              {/* Paid Orders */}
              <View className="p-4 border-b border-border flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-medium text-foreground">Concluído/Pago</Text>
                  <Text className="text-xs text-muted mt-1">
                    {orders.filter((o) => o.status === "paid").length} pedidos
                  </Text>
                </View>
                <Text className="text-lg font-bold text-green-600">
                  R$ {orders
                    .filter((o) => o.status === "paid")
                    .reduce((sum, o) => sum + o.total, 0)
                    .toFixed(2)}
                </Text>
              </View>

              {/* Owing Orders */}
              <View className="p-4 flex-row justify-between items-center">
                <View className="flex-1">
                  <Text className="text-sm font-medium text-foreground">Concluído/Devendo</Text>
                  <Text className="text-xs text-muted mt-1">
                    {orders.filter((o) => o.status === "pending_payment").length} pedidos
                  </Text>
                </View>
                <Text className="text-lg font-bold text-red-600">
                  R$ {orders
                    .filter((o) => o.status === "pending_payment")
                    .reduce((sum, o) => sum + o.total, 0)
                    .toFixed(2)}
                </Text>
              </View>
            </View>
          </View>

          {/* Expenses by Category */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Despesas por Categoria</Text>
            <View className="bg-surface border border-border rounded-2xl overflow-hidden">
              {[
                { key: "ingredientes", label: "Ingredientes", color: "text-blue-600" },
                { key: "embalagem", label: "Embalagem", color: "text-green-600" },
                { key: "transporte", label: "Transporte", color: "text-orange-600" },
                { key: "outros", label: "Outros", color: "text-gray-600" },
              ].map((category, index) => {
                const categoryExpenses = expenses.filter((e) => e.category === category.key);
                const total = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);
                return (
                  <View
                    key={category.key}
                    className={`p-4 flex-row justify-between items-center ${
                      index < 3 ? "border-b border-border" : ""
                    }`}
                  >
                    <View className="flex-1">
                      <Text className="text-sm font-medium text-foreground">{category.label}</Text>
                      <Text className="text-xs text-muted mt-1">{categoryExpenses.length} registros</Text>
                    </View>
                    <Text className={`text-lg font-bold ${category.color}`}>
                      R$ {total.toFixed(2)}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
