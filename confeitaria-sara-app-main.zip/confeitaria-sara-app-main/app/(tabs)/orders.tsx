import { ScrollView, Text, View, TouchableOpacity, FlatList, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useState, useMemo } from "react";
import { Order } from "@/types";
import { StatusSelector, getStatusLabel } from "@/components/status-selector";
import { useRouter } from "expo-router";

export default function OrdersScreen() {
  const router = useRouter();
  const { orders, deleteOrder, updateOrder, isLoading } = useData();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

  const filteredAndSortedOrders = useMemo(() => {
    const filtered = orders.filter((order) => {
      const orderDate = new Date(order.date);
      return orderDate.getMonth() === selectedMonth && orderDate.getFullYear() === selectedYear;
    });

    // Ordenar por data de entrega (mais próximos primeiro)
    return filtered.sort((a, b) => {
      const dateA = a.deliveryDate ? new Date(a.deliveryDate).getTime() : Infinity;
      const dateB = b.deliveryDate ? new Date(b.deliveryDate).getTime() : Infinity;
      return dateA - dateB;
    });
  }, [orders, selectedMonth, selectedYear]);

  const handleDeleteOrder = (orderId: string) => {
    Alert.alert("Confirmar", "Tem certeza que deseja deletar este pedido?", [
      { text: "Cancelar", onPress: () => {} },
      {
        text: "Deletar",
        onPress: async () => {
          try {
            await deleteOrder(orderId);
            Alert.alert("Sucesso", "Pedido deletado com sucesso");
          } catch (error) {
            Alert.alert("Erro", "Não foi possível deletar o pedido");
          }
        },
        style: "destructive",
      },
    ]);
  };

  const handleStatusChange = async (orderId: string, newStatus: "open" | "paid" | "pending_payment") => {
    const order = orders.find((o) => o.id === orderId);
    if (order) {
      try {
        await updateOrder({ ...order, status: newStatus });
      } catch (error) {
        Alert.alert("Erro", "Não foi possível atualizar o status");
      }
    }
  };

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ];

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  const renderOrderItem = ({ item }: { item: Order }) => (
    <View className="bg-surface border border-border rounded-lg mb-3 overflow-hidden">
      <TouchableOpacity
        onPress={() => setExpandedOrderId(expandedOrderId === item.id ? null : item.id)}
        className="p-4 active:opacity-70"
      >
        <View className="flex-row justify-between items-start mb-2">
          <View className="flex-1">
            <Text className="text-sm font-semibold text-foreground">{item.clientName}</Text>
            <Text className="text-xs text-muted mt-1">
              Pedido: {new Date(item.date).toLocaleString("pt-BR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </Text>
            {item.deliveryDate && (
              <Text className="text-xs text-primary mt-1">
                Entrega: {new Date(item.deliveryDate).toLocaleString("pt-BR", {
                  day: "2-digit",
                  month: "2-digit",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </Text>
            )}
          </View>
          <Text className="text-sm font-bold text-primary">R$ {item.total.toFixed(2)}</Text>
        </View>

        {/* Status Badge */}
        <View className="mt-2">
          <View
            className={`inline-flex rounded-full px-3 py-1 ${
              item.status === "open"
                ? "bg-warning"
                : item.status === "paid"
                  ? "bg-success"
                  : "bg-error"
            }`}
          >
            <Text className="text-white text-xs font-semibold">
              {getStatusLabel(item.status)}
            </Text>
          </View>
        </View>
      </TouchableOpacity>

      {/* Expanded Details */}
      {expandedOrderId === item.id && (
        <View className="bg-background border-t border-border p-4 gap-3">
          {/* Products List */}
          <View className="gap-2">
            <Text className="text-xs font-semibold text-muted uppercase">Produtos</Text>
            {item.items.map((orderItem, index) => (
              <Text key={index} className="text-xs text-foreground">
                {orderItem.productName} × {orderItem.quantity} uni - R$ {orderItem.subtotal.toFixed(2)}
              </Text>
            ))}
          </View>

          {/* Status Selector */}
          <View className="gap-2">
            <Text className="text-xs font-semibold text-muted uppercase">Alterar Status</Text>
            <StatusSelector
              status={item.status}
              onStatusChange={(newStatus) => handleStatusChange(item.id, newStatus)}
            />
          </View>

          {/* Notes */}
          {item.notes && (
            <View className="gap-1">
              <Text className="text-xs font-semibold text-muted">Observações:</Text>
              <Text className="text-xs text-foreground">{item.notes}</Text>
            </View>
          )}

          {/* Action Buttons */}
          <View className="flex-row gap-2">
            <TouchableOpacity
              onPress={() => router.push(`/edit-order?orderId=${item.id}`)}
              className="flex-1 bg-primary rounded-lg p-2 active:opacity-70"
            >
              <Text className="text-center text-white text-xs font-semibold">Editar</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => handleDeleteOrder(item.id)}
              className="flex-1 bg-error rounded-lg p-2 active:opacity-70"
            >
              <Text className="text-center text-white text-xs font-semibold">Deletar</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );

  return (
    <ScreenContainer className="p-4">
      <View className="gap-4 flex-1">
        {/* Header */}
        <View className="gap-2">
          <Text className="text-2xl font-bold text-foreground">Histórico de Pedidos</Text>
          <Text className="text-sm text-muted">Ordenado por data de entrega</Text>
        </View>

        {/* Month/Year Selector */}
        <View className="bg-surface border border-border rounded-lg p-3 gap-2">
          <View className="flex-row gap-2">
            <TouchableOpacity
              onPress={() => {
                if (selectedMonth === 0) {
                  setSelectedMonth(11);
                  setSelectedYear(selectedYear - 1);
                } else {
                  setSelectedMonth(selectedMonth - 1);
                }
              }}
              className="flex-1 bg-primary rounded-lg p-2 active:opacity-80"
            >
              <Text className="text-center text-white text-xs font-semibold">← Anterior</Text>
            </TouchableOpacity>

            <View className="flex-1 items-center justify-center">
              <Text className="text-sm font-semibold text-foreground">
                {monthNames[selectedMonth]} {selectedYear}
              </Text>
            </View>

            <TouchableOpacity
              onPress={() => {
                if (selectedMonth === 11) {
                  setSelectedMonth(0);
                  setSelectedYear(selectedYear + 1);
                } else {
                  setSelectedMonth(selectedMonth + 1);
                }
              }}
              className="flex-1 bg-primary rounded-lg p-2 active:opacity-80"
            >
              <Text className="text-center text-white text-xs font-semibold">Próximo →</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Orders List */}
        {filteredAndSortedOrders.length > 0 ? (
          <FlatList
            data={filteredAndSortedOrders}
            renderItem={renderOrderItem}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        ) : (
          <View className="flex-1 items-center justify-center gap-2">
            <Text className="text-base font-semibold text-foreground">Nenhum pedido encontrado</Text>
            <Text className="text-xs text-muted">Nenhum pedido registrado para este período</Text>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}
