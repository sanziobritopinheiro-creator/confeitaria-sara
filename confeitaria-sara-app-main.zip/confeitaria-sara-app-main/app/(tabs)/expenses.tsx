import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Expense } from "@/types";
import { QRCodeScanner } from "@/components/qr-code-scanner";

export default function ExpensesScreen() {
  const router = useRouter();
  const { getExpensesByMonth, addExpense, deleteExpense, isLoading } = useData();
  const [showForm, setShowForm] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState<"ingredientes" | "embalagem" | "transporte" | "outros">("ingredientes");
  const [notes, setNotes] = useState("");

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthExpenses = useMemo(
    () => getExpensesByMonth(currentMonth, currentYear),
    [currentMonth, currentYear, getExpensesByMonth]
  );

  const totalExpenses = monthExpenses.reduce((sum, exp) => sum + exp.amount, 0);

  const categoryLabels = {
    ingredientes: "Ingredientes",
    embalagem: "Embalagem",
    transporte: "Transporte",
    outros: "Outros",
  };

  const categoryColors = {
    ingredientes: "bg-blue-100 text-blue-700",
    embalagem: "bg-green-100 text-green-700",
    transporte: "bg-orange-100 text-orange-700",
    outros: "bg-gray-100 text-gray-700",
  };

  const handleQRCodeScan = (qrData: string) => {
    // Tentar extrair informações do QR code
    // Formato esperado: pode variar, mas geralmente contém dados da nota fiscal
    try {
      // Exemplo simples: se o QR code contiver um valor numérico, usar como amount
      const lines = qrData.split("\n");
      let extractedAmount = "";
      let extractedDescription = "";

      // Procurar por padrões de valor (números com ponto ou vírgula)
      lines.forEach((line) => {
        const valueMatch = line.match(/(\d+[.,]\d{2})/);
        if (valueMatch && !extractedAmount) {
          extractedAmount = valueMatch[1].replace(",", ".");
        }
        // Procurar por descrição (texto que não é número)
        if (!line.match(/^\d/) && line.length > 3 && !extractedDescription) {
          extractedDescription = line.substring(0, 50);
        }
      });

      if (extractedAmount) {
        setAmount(extractedAmount);
      }
      if (extractedDescription) {
        setDescription(extractedDescription);
      }

      setShowScanner(false);
      setShowForm(true);

      Alert.alert(
        "QR Code Lido",
        `Valor: R$ ${extractedAmount || "não encontrado"}\nDescrição: ${extractedDescription || "não encontrada"}`
      );
    } catch (error) {
      Alert.alert("Erro", "Não foi possível processar o QR code");
      setShowScanner(false);
    }
  };

  const handleAddExpense = async () => {
    if (!description || !amount) {
      Alert.alert("Erro", "Por favor, preencha descrição e valor");
      return;
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      Alert.alert("Erro", "Valor deve ser um número positivo");
      return;
    }

    const expense: Expense = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      amount: amountNum,
      category,
      description,
      notes: notes || undefined,
    };

    try {
      await addExpense(expense);
      setDescription("");
      setAmount("");
      setCategory("ingredientes");
      setNotes("");
      setShowForm(false);
      Alert.alert("Sucesso", "Despesa adicionada com sucesso");
    } catch (error) {
      Alert.alert("Erro", "Não foi possível adicionar a despesa");
    }
  };

  const handleDeleteExpense = (expenseId: string) => {
    Alert.alert("Confirmar", "Deseja deletar esta despesa?", [
      { text: "Cancelar", onPress: () => {} },
      {
        text: "Deletar",
        onPress: async () => {
          try {
            await deleteExpense(expenseId);
            Alert.alert("Sucesso", "Despesa deletada");
          } catch (error) {
            Alert.alert("Erro", "Não foi possível deletar a despesa");
          }
        },
      },
    ]);
  };

  if (showScanner) {
    return (
      <View className="flex-1">
        <QRCodeScanner
          onScan={handleQRCodeScan}
          onClose={() => setShowScanner(false)}
        />
      </View>
    );
  }

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Despesas</Text>
            <Text className="text-base text-muted">
              {new Date(currentYear, currentMonth).toLocaleString("pt-BR", { month: "long", year: "numeric" })}
            </Text>
          </View>

          {/* Total Expenses Card */}
          <View className="bg-red-500 rounded-2xl p-6">
            <Text className="text-sm text-white opacity-80 mb-1">Total de Despesas</Text>
            <Text className="text-3xl font-bold text-white">
              R$ {totalExpenses.toFixed(2)}
            </Text>
            <Text className="text-xs text-white opacity-60 mt-2">
              {monthExpenses.length} registros
            </Text>
          </View>

          {/* Action Buttons */}
          <View className="flex-row gap-3">
            <TouchableOpacity
              onPress={() => setShowForm(!showForm)}
              className="flex-1 bg-primary rounded-2xl p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-semibold">+ Nova Despesa</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setShowScanner(true)}
              className="flex-1 bg-blue-500 rounded-2xl p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-semibold">📷 QR Code</Text>
            </TouchableOpacity>
          </View>

          {/* Add Expense Form */}
          {showForm && (
            <View className="bg-surface border border-border rounded-2xl p-4 gap-4">
              {/* Description */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-foreground">Descrição</Text>
                <TextInput
                  value={description}
                  onChangeText={setDescription}
                  placeholder="Ex: Chocolate em pó"
                  placeholderTextColor="#999"
                  className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                />
              </View>

              {/* Amount */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-foreground">Valor (R$)</Text>
                <TextInput
                  value={amount}
                  onChangeText={setAmount}
                  placeholder="0.00"
                  placeholderTextColor="#999"
                  keyboardType="decimal-pad"
                  className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                />
              </View>

              {/* Category */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-foreground">Categoria</Text>
                <View className="flex-row gap-2 flex-wrap">
                  {(["ingredientes", "embalagem", "transporte", "outros"] as const).map((cat) => (
                    <TouchableOpacity
                      key={cat}
                      onPress={() => setCategory(cat)}
                      className={`rounded-lg px-3 py-2 ${
                        category === cat ? "bg-primary" : "bg-background border border-border"
                      }`}
                    >
                      <Text
                        className={`text-xs font-semibold ${
                          category === cat ? "text-white" : "text-foreground"
                        }`}
                      >
                        {categoryLabels[cat]}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Notes */}
              <View className="gap-2">
                <Text className="text-xs font-semibold text-foreground">Notas (opcional)</Text>
                <TextInput
                  value={notes}
                  onChangeText={setNotes}
                  placeholder="Adicione notas sobre a despesa"
                  placeholderTextColor="#999"
                  multiline
                  numberOfLines={3}
                  className="bg-background border border-border rounded-lg px-3 py-2 text-foreground"
                />
              </View>

              {/* Action Buttons */}
              <View className="flex-row gap-2 mt-2">
                <TouchableOpacity
                  onPress={handleAddExpense}
                  className="flex-1 bg-primary rounded-lg p-3 active:opacity-80"
                >
                  <Text className="text-center text-white font-semibold">Adicionar</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setShowForm(false)}
                  className="flex-1 bg-surface border border-border rounded-lg p-3 active:opacity-70"
                >
                  <Text className="text-center text-foreground font-semibold">Cancelar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Expenses List */}
          {monthExpenses.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">Histórico de Despesas</Text>
              <View className="bg-surface rounded-2xl border border-border overflow-hidden">
                {monthExpenses
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((expense, index) => (
                    <View
                      key={expense.id}
                      className={`p-4 flex-row justify-between items-center ${
                        index < monthExpenses.length - 1 ? "border-b border-border" : ""
                      }`}
                    >
                      <View className="flex-1">
                        <Text className="text-sm font-medium text-foreground">{expense.description}</Text>
                        <View className="flex-row gap-2 mt-1">
                          <View className={`rounded-full px-2 py-1 ${categoryColors[expense.category]}`}>
                            <Text className="text-xs font-semibold">{categoryLabels[expense.category]}</Text>
                          </View>
                          <Text className="text-xs text-muted">
                            {new Date(expense.date).toLocaleDateString("pt-BR")}
                          </Text>
                        </View>
                      </View>
                      <View className="items-end gap-2">
                        <Text className="text-sm font-semibold text-error">
                          -R$ {expense.amount.toFixed(2)}
                        </Text>
                        <TouchableOpacity
                          onPress={() => handleDeleteExpense(expense.id)}
                          className="active:opacity-70"
                        >
                          <Text className="text-xs text-error font-medium">Deletar</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  ))}
              </View>
            </View>
          )}

          {monthExpenses.length === 0 && !showForm && (
            <View className="items-center justify-center py-8">
              <Text className="text-muted text-center">Nenhuma despesa registrada neste mês</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
