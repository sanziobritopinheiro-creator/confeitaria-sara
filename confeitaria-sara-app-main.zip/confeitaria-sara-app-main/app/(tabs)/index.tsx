import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useRouter } from "expo-router";
import { useMemo, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function HomeScreen() {
  const router = useRouter();
  const { getMonthlySalesData, isLoading } = useData();
  const [showValues, setShowValues] = useState(true);

  useEffect(() => {
    loadShowValuesPreference();
  }, []);

  const loadShowValuesPreference = async () => {
    try {
      const saved = await AsyncStorage.getItem("showSalesValues");
      if (saved !== null) {
        setShowValues(JSON.parse(saved));
      }
    } catch (error) {
      console.error("Erro ao carregar preferência:", error);
    }
  };

  const toggleShowValues = async () => {
    try {
      const newValue = !showValues;
      setShowValues(newValue);
      await AsyncStorage.setItem("showSalesValues", JSON.stringify(newValue));
    } catch (error) {
      console.error("Erro ao salvar preferência:", error);
    }
  };

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthlySalesData = useMemo(
    () => getMonthlySalesData(currentMonth, currentYear),
    [currentMonth, currentYear, getMonthlySalesData]
  );

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Confeitaria da Sara</Text>
            <Text className="text-base text-muted">
              {monthlySalesData.month} de {currentYear}
            </Text>
          </View>

          {/* Sales Summary Cards */}
          <View className="gap-3">
            {/* Total Sales Card */}
            <View className="bg-primary rounded-2xl p-6">
              <View className="flex-row justify-between items-start mb-2">
                <Text className="text-sm text-white opacity-80">Vendas do Mês</Text>
                <TouchableOpacity
                  onPress={toggleShowValues}
                  className="bg-white bg-opacity-20 rounded-full p-2 active:opacity-70"
                >
                  <Text className="text-white text-xs font-semibold w-5 text-center">
                    {showValues ? "👁" : "🔒"}
                  </Text>
                </TouchableOpacity>
              </View>
              <Text className="text-3xl font-bold text-white">
                {showValues ? `R$ ${monthlySalesData.totalSales.toFixed(2)}` : "••••••"}
              </Text>
              <Text className="text-xs text-white opacity-60 mt-2">
                {monthlySalesData.totalOrders} pedidos
              </Text>
            </View>

            {/* Orders Count Card */}
            <View className="flex-row gap-3">
              <View className="flex-1 bg-surface rounded-2xl p-4 border border-border">
                <Text className="text-xs text-muted mb-2">Total de Pedidos</Text>
                <Text className="text-2xl font-bold text-foreground">
                  {showValues ? monthlySalesData.totalOrders : "••"}
                </Text>
              </View>

              <View className="flex-1 bg-surface rounded-2xl p-4 border border-border">
                <Text className="text-xs text-muted mb-2">Dias Ativos</Text>
                <Text className="text-2xl font-bold text-foreground">
                  {showValues ? monthlySalesData.dailySales.length : "••"}
                </Text>
              </View>
            </View>
          </View>

          {/* Top Products */}
          {monthlySalesData.productSales.length > 0 && showValues && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">Produtos Mais Vendidos</Text>
              <View className="bg-surface rounded-2xl border border-border overflow-hidden">
                {monthlySalesData.productSales.slice(0, 5).map((product, index) => (
                  <View
                    key={index}
                    className={`p-4 flex-row justify-between items-center ${
                      index < 4 ? "border-b border-border" : ""
                    }`}
                  >
                    <View className="flex-1">
                      <Text className="text-sm font-medium text-foreground">{product.productName}</Text>
                      <Text className="text-xs text-muted mt-1">{product.quantity} unidades</Text>
                    </View>
                    <Text className="text-sm font-semibold text-primary">
                      R$ {product.total.toFixed(2)}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Quick Actions */}
          <View className="gap-3 mt-4">
            <TouchableOpacity
              onPress={() => router.push("/new-order")}
              className="bg-primary rounded-2xl p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-semibold">+ Novo Pedido</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push("/reports")}
              className="bg-surface border border-border rounded-2xl p-4 active:opacity-80"
            >
              <Text className="text-center text-foreground font-semibold">Ver Relatório Completo</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
