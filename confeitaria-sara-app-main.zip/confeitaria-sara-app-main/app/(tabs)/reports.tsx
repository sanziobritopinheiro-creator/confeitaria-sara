import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useState, useMemo } from "react";

export default function ReportsScreen() {
  const { getMonthlySalesData, isLoading } = useData();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const monthlySalesData = useMemo(
    () => getMonthlySalesData(selectedMonth, selectedYear),
    [selectedMonth, selectedYear, getMonthlySalesData]
  );

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ];

  if (isLoading) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  // Calcular maior valor para escala do gráfico
  const maxDailySales = Math.max(...monthlySalesData.dailySales.map((d) => d.total), 1);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Relatório de Vendas</Text>
            <Text className="text-sm text-muted">Análise detalhada do mês</Text>
          </View>

          {/* Month/Year Filter */}
          <View className="bg-surface border border-border rounded-lg p-3 flex-row justify-between items-center">
            <TouchableOpacity
              onPress={() => {
                if (selectedMonth === 0) {
                  setSelectedMonth(11);
                  setSelectedYear(selectedYear - 1);
                } else {
                  setSelectedMonth(selectedMonth - 1);
                }
              }}
              className="active:opacity-70"
            >
              <Text className="text-foreground font-semibold">←</Text>
            </TouchableOpacity>

            <Text className="text-sm font-semibold text-foreground">
              {monthNames[selectedMonth]} {selectedYear}
            </Text>

            <TouchableOpacity
              onPress={() => {
                if (selectedMonth === 11) {
                  setSelectedMonth(0);
                  setSelectedYear(selectedYear + 1);
                } else {
                  setSelectedMonth(selectedMonth + 1);
                }
              }}
              className="active:opacity-70"
            >
              <Text className="text-foreground font-semibold">→</Text>
            </TouchableOpacity>
          </View>

          {/* Summary Cards */}
          <View className="gap-3">
            <View className="bg-primary rounded-lg p-4">
              <Text className="text-xs text-white opacity-80 mb-1">Total de Vendas</Text>
              <Text className="text-3xl font-bold text-white">
                R$ {monthlySalesData.totalSales.toFixed(2)}
              </Text>
            </View>

            <View className="flex-row gap-3">
              <View className="flex-1 bg-surface border border-border rounded-lg p-4">
                <Text className="text-xs text-muted mb-2">Pedidos</Text>
                <Text className="text-2xl font-bold text-foreground">{monthlySalesData.totalOrders}</Text>
              </View>

              <View className="flex-1 bg-surface border border-border rounded-lg p-4">
                <Text className="text-xs text-muted mb-2">Ticket Médio</Text>
                <Text className="text-2xl font-bold text-foreground">
                  R$ {(monthlySalesData.totalSales / Math.max(monthlySalesData.totalOrders, 1)).toFixed(2)}
                </Text>
              </View>
            </View>
          </View>

          {/* Daily Sales Chart */}
          {monthlySalesData.dailySales.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">Vendas por Dia</Text>
              <View className="bg-surface border border-border rounded-lg p-4">
                {monthlySalesData.dailySales.map((daily, index) => {
                  const percentage = (daily.total / maxDailySales) * 100;
                  const day = new Date(daily.date).getDate();

                  return (
                    <View key={index} className="mb-4">
                      <View className="flex-row justify-between items-center mb-2">
                        <Text className="text-xs font-medium text-foreground">Dia {day}</Text>
                        <Text className="text-xs font-semibold text-primary">
                          R$ {daily.total.toFixed(2)}
                        </Text>
                      </View>
                      <View className="h-6 bg-background rounded-full overflow-hidden">
                        <View
                          className="h-full bg-primary rounded-full"
                          style={{ width: `${percentage}%` }}
                        />
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {/* Top Products */}
          {monthlySalesData.productSales.length > 0 && (
            <View className="gap-3">
              <Text className="text-lg font-semibold text-foreground">Produtos Mais Vendidos</Text>
              <View className="bg-surface border border-border rounded-lg overflow-hidden">
                {monthlySalesData.productSales.map((product, index) => (
                  <View
                    key={index}
                    className={`p-4 ${index < monthlySalesData.productSales.length - 1 ? "border-b border-border" : ""}`}
                  >
                    <View className="flex-row justify-between items-start mb-2">
                      <View className="flex-1">
                        <Text className="text-sm font-medium text-foreground">{product.productName}</Text>
                        <Text className="text-xs text-muted mt-1">{product.quantity} unidades</Text>
                      </View>
                      <Text className="text-sm font-bold text-primary">R$ {product.total.toFixed(2)}</Text>
                    </View>

                    {/* Product percentage bar */}
                    <View className="h-4 bg-background rounded-full overflow-hidden">
                      <View
                        className="h-full bg-primary rounded-full"
                        style={{
                          width: `${(product.total / monthlySalesData.totalSales) * 100}%`,
                        }}
                      />
                    </View>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Empty State */}
          {monthlySalesData.totalOrders === 0 && (
            <View className="flex-1 items-center justify-center py-8">
              <Text className="text-muted text-center">Nenhum pedido neste mês</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
