import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useData } from "@/lib/data-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState, useEffect, useMemo } from "react";
import { Order, OrderItem } from "@/types";
import { FractionSelector } from "@/components/fraction-selector";
import { DeliveryDateTimePicker } from "@/components/delivery-datetime-picker";
import { StatusSelector } from "@/components/status-selector";

export default function EditOrderScreen() {
  const router = useRouter();
  const { orderId } = useLocalSearchParams<{ orderId: string }>();
  const { orders, updateOrder, isLoading } = useData();

  const order = useMemo(() => orders.find((o) => o.id === orderId), [orders, orderId]);

  const [clientName, setClientName] = useState("");
  const [items, setItems] = useState<OrderItem[]>([]);
  const [deliveryDate, setDeliveryDate] = useState<string | undefined>();
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<"open" | "paid" | "pending_payment">("open");
  const [isSaving, setIsSaving] = useState(false);

  const { products } = useData();

  useEffect(() => {
    if (order) {
      setClientName(order.clientName);
      setItems(order.items);
      setDeliveryDate(order.deliveryDate);
      setNotes(order.notes || "");
      setStatus(order.status);
    }
  }, [order]);

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + item.subtotal, 0);
  };

  const total = calculateTotal();

  const handleFractionsChange = (productId: string, fractions: number[]) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    const totalQuantity = fractions.reduce((sum, f) => sum + f, 0);
    const totalSubtotal = (totalQuantity / 100) * product.price;

    const existingItem = items.find((item) => item.productId === productId);

    if (existingItem) {
      setItems(
        items.map((item) =>
          item.productId === productId
            ? {
                ...item,
                quantity: totalQuantity,
                subtotal: totalSubtotal,
                fractions,
              }
            : item
        )
      );
    } else if (fractions.length > 0) {
      setItems([
        ...items,
        {
          productId,
          productName: product.name,
          quantity: totalQuantity,
          price: product.price,
          subtotal: totalSubtotal,
          fractions,
        },
      ]);
    }
  };

  const handleRemoveItem = (productId: string) => {
    setItems(items.filter((item) => item.productId !== productId));
  };

  const handleSave = async () => {
    if (!clientName.trim()) {
      Alert.alert("Erro", "Por favor, insira o nome do cliente");
      return;
    }

    if (items.length === 0) {
      Alert.alert("Erro", "Por favor, adicione pelo menos um produto");
      return;
    }

    if (!order) return;

    setIsSaving(true);

    try {
      const updatedOrder: Order = {
        ...order,
        clientName,
        items,
        total,
        deliveryDate,
        notes: notes || undefined,
        status,
      };

      await updateOrder(updatedOrder);
      Alert.alert("Sucesso", "Pedido atualizado com sucesso!");
      router.back();
    } catch (error) {
      Alert.alert("Erro", "Não foi possível atualizar o pedido");
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading || !order) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <ActivityIndicator size="large" color="#D946A6" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Editar Pedido</Text>
            <Text className="text-sm text-muted">Atualize as informações do pedido</Text>
          </View>

          {/* Client Name */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Nome do Cliente</Text>
            <TextInput
              value={clientName}
              onChangeText={setClientName}
              placeholder="Digite o nome do cliente"
              placeholderTextColor="#999"
              className="bg-surface border border-border rounded-lg p-3 text-foreground"
            />
          </View>

          {/* Products */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">Produtos</Text>

            {/* Selected Items */}
            {items.length > 0 && (
              <View className="bg-surface border border-border rounded-lg p-3 gap-2">
                {items.map((item) => (
                  <View key={item.productId} className="flex-row justify-between items-center pb-2 border-b border-border">
                    <View className="flex-1">
                      <Text className="text-sm font-semibold text-foreground">{item.productName}</Text>
                      <Text className="text-xs text-muted mt-1">
                        {item.quantity} uni - R$ {item.subtotal.toFixed(2)}
                      </Text>
                    </View>
                    <TouchableOpacity
                      onPress={() => handleRemoveItem(item.productId)}
                      className="bg-error rounded-lg px-3 py-1 active:opacity-70"
                    >
                      <Text className="text-white text-xs font-semibold">Remover</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}

            {/* Add Products */}
            <View className="gap-2">
              {products.map((product) => {
                const existingItem = items.find((item) => item.productId === product.id);
                const currentFractions = existingItem?.fractions || [];

                return (
                  <View key={product.id} className="bg-surface border border-border rounded-lg p-3">
                    <View className="flex-row justify-between items-center mb-2">
                      <View className="flex-1">
                        <Text className="text-sm font-semibold text-foreground">{product.name}</Text>
                        <Text className="text-xs text-muted mt-1">R$ {product.price.toFixed(2)} (100 uni)</Text>
                      </View>
                    </View>
                    <FractionSelector
                      fractions={currentFractions}
                      productName={product.name}
                      pricePerHundred={product.price}
                      onFractionsChange={(fractions) => handleFractionsChange(product.id, fractions)}
                    />
                  </View>
                );
              })}
            </View>
          </View>

          {/* Delivery Date */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Data e Hora de Entrega</Text>
            <DeliveryDateTimePicker
              deliveryDate={deliveryDate}
              onDeliveryDateChange={setDeliveryDate}
            />
          </View>

          {/* Status */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Status do Pedido</Text>
            <StatusSelector status={status} onStatusChange={setStatus} />
          </View>

          {/* Notes */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Observações</Text>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              placeholder="Adicione observações sobre o pedido"
              placeholderTextColor="#999"
              multiline
              numberOfLines={4}
              className="bg-surface border border-border rounded-lg p-3 text-foreground"
            />
          </View>

          {/* Total */}
          <View className="bg-primary rounded-2xl p-4 gap-2">
            <Text className="text-sm text-white opacity-80">Total do Pedido</Text>
            <Text className="text-3xl font-bold text-white">R$ {total.toFixed(2)}</Text>
          </View>

          {/* Action Buttons */}
          <View className="flex-row gap-3">
            <TouchableOpacity
              onPress={() => router.back()}
              className="flex-1 bg-surface border border-border rounded-lg p-3 active:opacity-70"
              disabled={isSaving}
            >
              <Text className="text-center text-foreground font-semibold">Cancelar</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleSave}
              className="flex-1 bg-primary rounded-lg p-3 active:opacity-80"
              disabled={isSaving}
            >
              <Text className="text-center text-white font-semibold">
                {isSaving ? "Salvando..." : "Salvar Alterações"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
