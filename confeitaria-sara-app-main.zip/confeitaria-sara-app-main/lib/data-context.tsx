import { createContext, useContext, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Order, Product, MonthlySalesData, Expense, FinancialSummary } from "@/types";

interface DataContextType {
  products: Product[];
  orders: Order[];
  expenses: Expense[];
  addOrder: (order: Order) => Promise<void>;
  updateOrder: (order: Order) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  addExpense: (expense: Expense) => Promise<void>;
  updateExpense: (expense: Expense) => Promise<void>;
  deleteExpense: (expenseId: string) => Promise<void>;
  getOrdersByMonth: (month: number, year: number) => Order[];
  getExpensesByMonth: (month: number, year: number) => Expense[];
  getMonthlySalesData: (month: number, year: number) => MonthlySalesData;
  getFinancialSummary: (month: number, year: number) => FinancialSummary;
  isLoading: boolean;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const DEFAULT_PRODUCTS: Product[] = [
  { id: "1", name: "Brigadeiro", price: 110, category: "doces" },
  { id: "2", name: "Cajuzinho", price: 110, category: "doces" },
  { id: "3", name: "Brigadeiro/Amendoim", price: 110, category: "doces" },
  { id: "4", name: "Moranguinho", price: 160, category: "doces" },
  { id: "6", name: "Bombom", price: 170, category: "doces" },
  { id: "7", name: "Docinho Dois Amores", price: 120, category: "doces" },
  { id: "8", name: "Olho de Sogra", price: 130, category: "doces" },
  { id: "9", name: "Beijinho de Coco", price: 110, category: "doces" },
  { id: "10", name: "Pastel Pocadinho", price: 110, category: "salgados" },
  { id: "11", name: "Pastel de Milho", price: 110, category: "salgados" },
  { id: "12", name: "Pastel Assado", price: 110, category: "salgados" },
  { id: "13", name: "Coxinha", price: 110, category: "salgados" },
  { id: "14", name: "Empada", price: 110, category: "salgados" },
  { id: "15", name: "Bolinha Pres. Queijo", price: 110, category: "salgados" },
  { id: "16", name: "Cigarrete", price: 140, category: "salgados" },
  { id: "17", name: "Salgados Misto", price: 120, category: "salgados" },
];

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [products] = useState<Product[]>(DEFAULT_PRODUCTS);
  const [orders, setOrders] = useState<Order[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar dados do AsyncStorage ao iniciar
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [storedOrders, storedExpenses] = await Promise.all([
        AsyncStorage.getItem("orders"),
        AsyncStorage.getItem("expenses"),
      ]);

      if (storedOrders) {
        setOrders(JSON.parse(storedOrders));
      }
      if (storedExpenses) {
        setExpenses(JSON.parse(storedExpenses));
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveOrders = async (newOrders: Order[]) => {
    try {
      await AsyncStorage.setItem("orders", JSON.stringify(newOrders));
      setOrders(newOrders);
    } catch (error) {
      console.error("Erro ao salvar pedidos:", error);
    }
  };

  const saveExpenses = async (newExpenses: Expense[]) => {
    try {
      await AsyncStorage.setItem("expenses", JSON.stringify(newExpenses));
      setExpenses(newExpenses);
    } catch (error) {
      console.error("Erro ao salvar despesas:", error);
    }
  };

  const addOrder = async (order: Order) => {
    const newOrders = [...orders, order];
    await saveOrders(newOrders);
  };

  const updateOrder = async (updatedOrder: Order) => {
    const newOrders = orders.map((o) => (o.id === updatedOrder.id ? updatedOrder : o));
    await saveOrders(newOrders);
  };

  const deleteOrder = async (orderId: string) => {
    const newOrders = orders.filter((o) => o.id !== orderId);
    await saveOrders(newOrders);
  };

  const addExpense = async (expense: Expense) => {
    const newExpenses = [...expenses, expense];
    await saveExpenses(newExpenses);
  };

  const updateExpense = async (updatedExpense: Expense) => {
    const newExpenses = expenses.map((e) => (e.id === updatedExpense.id ? updatedExpense : e));
    await saveExpenses(newExpenses);
  };

  const deleteExpense = async (expenseId: string) => {
    const newExpenses = expenses.filter((e) => e.id !== expenseId);
    await saveExpenses(newExpenses);
  };

  const getOrdersByMonth = (month: number, year: number) => {
    return orders.filter((order) => {
      const orderDate = new Date(order.date);
      return orderDate.getMonth() === month && orderDate.getFullYear() === year;
    });
  };

  const getExpensesByMonth = (month: number, year: number) => {
    return expenses.filter((expense) => {
      const expenseDate = new Date(expense.date);
      return expenseDate.getMonth() === month && expenseDate.getFullYear() === year;
    });
  };

  const getMonthlySalesData = (month: number, year: number): MonthlySalesData => {
    const monthOrders = getOrdersByMonth(month, year);
    const monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ];

    // Calcular vendas por dia
    const dailySalesMap = new Map<string, { total: number; orderCount: number }>();
    monthOrders.forEach((order) => {
      const date = order.date.split("T")[0];
      const current = dailySalesMap.get(date) || { total: 0, orderCount: 0 };
      dailySalesMap.set(date, {
        total: current.total + order.total,
        orderCount: current.orderCount + 1,
      });
    });

    const dailySales = Array.from(dailySalesMap.entries()).map(([date, data]) => ({
      date,
      ...data,
    }));

    // Calcular vendas por produto
    const productSalesMap = new Map<string, { quantity: number; total: number }>();
    monthOrders.forEach((order) => {
      order.items.forEach((item) => {
        const current = productSalesMap.get(item.productName) || { quantity: 0, total: 0 };
        productSalesMap.set(item.productName, {
          quantity: current.quantity + item.quantity,
          total: current.total + item.subtotal,
        });
      });
    });

    const productSales = Array.from(productSalesMap.entries()).map(([productName, data]) => ({
      productName,
      ...data,
    }));

    return {
      month: monthNames[month],
      year,
      totalSales: monthOrders.reduce((sum, order) => sum + order.total, 0),
      totalOrders: monthOrders.length,
      dailySales: dailySales.sort((a, b) => a.date.localeCompare(b.date)),
      productSales: productSales.sort((a, b) => b.total - a.total),
    };
  };

  const getFinancialSummary = (month: number, year: number): FinancialSummary => {
    const monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ];

    const monthOrders = getOrdersByMonth(month, year);
    const monthExpenses = getExpensesByMonth(month, year);

    const totalRevenue = monthOrders.reduce((sum, order) => sum + order.total, 0);
    const totalExpenses = monthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
    const profit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;

    return {
      month: monthNames[month],
      year,
      totalRevenue,
      totalExpenses,
      profit,
      profitMargin,
    };
  };

  return (
    <DataContext.Provider
      value={{
        products,
        orders,
        expenses,
        addOrder,
        updateOrder,
        deleteOrder,
        addExpense,
        updateExpense,
        deleteExpense,
        getOrdersByMonth,
        getExpensesByMonth,
        getMonthlySalesData,
        getFinancialSummary,
        isLoading,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData deve ser usado dentro de DataProvider");
  }
  return context;
}
