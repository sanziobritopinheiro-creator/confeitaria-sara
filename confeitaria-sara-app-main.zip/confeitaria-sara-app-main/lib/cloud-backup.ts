import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { Order, Expense } from "@/types";

interface BackupData {
  timestamp: string;
  version: string;
  orders: Order[];
  expenses: Expense[];
}

/**
 * Serviço de Backup em Nuvem
 * Permite exportar e importar dados para sincronização
 */
export const CloudBackupService = {
  /**
   * Cria um arquivo de backup com todos os dados
   */
  async createBackup(orders: Order[], expenses: Expense[]): Promise<string> {
    try {
      const backupData: BackupData = {
        timestamp: new Date().toISOString(),
        version: "1.0.0",
        orders,
        expenses,
      };

      const fileName = `confeitaria-sara-backup-${new Date().toISOString().split("T")[0]}.json`;
      const filePath = `${FileSystem.documentDirectory}${fileName}`;

      if (!FileSystem.documentDirectory) {
        throw new Error("Diretório de documentos não disponível");
      }

      await FileSystem.writeAsStringAsync(filePath, JSON.stringify(backupData, null, 2));

      return filePath;
    } catch (error) {
      console.error("Erro ao criar backup:", error);
      throw new Error("Não foi possível criar o backup");
    }
  },

  /**
   * Compartilha o arquivo de backup
   */
  async shareBackup(filePath: string): Promise<void> {
    try {
      const fileName = filePath.split("/").pop() || "backup.json";

      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(filePath, {
          mimeType: "application/json",
          dialogTitle: "Compartilhar Backup",
          UTI: "public.json",
        });
      } else {
        throw new Error("Compartilhamento não disponível neste dispositivo");
      }
    } catch (error) {
      console.error("Erro ao compartilhar backup:", error);
      throw new Error("Não foi possível compartilhar o backup");
    }
  },

  /**
   * Restaura dados a partir de um arquivo de backup
   */
  async restoreFromBackup(backupContent: string): Promise<BackupData> {
    try {
      const backupData: BackupData = JSON.parse(backupContent);

      // Validar estrutura do backup
      if (!backupData.orders || !backupData.expenses) {
        throw new Error("Formato de backup inválido");
      }

      return backupData;
    } catch (error) {
      console.error("Erro ao restaurar backup:", error);
      throw new Error("Não foi possível restaurar o backup");
    }
  },

  /**
   * Gera um resumo do backup
   */
  getBackupSummary(backupData: BackupData): {
    timestamp: string;
    orderCount: number;
    expenseCount: number;
    totalRevenue: number;
    totalExpenses: number;
  } {
    const totalRevenue = backupData.orders.reduce((sum, order) => sum + order.total, 0);
    const totalExpenses = backupData.expenses.reduce((sum, expense) => sum + expense.amount, 0);

    return {
      timestamp: backupData.timestamp,
      orderCount: backupData.orders.length,
      expenseCount: backupData.expenses.length,
      totalRevenue,
      totalExpenses,
    };
  },

  /**
   * Exporta dados em formato CSV para planilhas
   */
  async exportToCSV(orders: Order[], expenses: Expense[]): Promise<string> {
    try {
      let csvContent = "PEDIDOS\n";
      csvContent += "Data,Cliente,Telefone,Itens,Total,Status,Data Entrega\n";

      orders.forEach((order) => {
        const itemsDescription = order.items.map((item) => `${item.productName}(${item.quantity}un)`).join("; ");
        const deliveryDate = order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString("pt-BR") : "";
        csvContent += `"${order.date}","${order.clientName}","${order.clientPhone || ""}","${itemsDescription}",${order.total.toFixed(2)},"${order.status}","${deliveryDate}"\n`;
      });

      csvContent += "\n\nDESPESAS\n";
      csvContent += "Data,Categoria,Descrição,Valor\n";

      expenses.forEach((expense) => {
        csvContent += `"${expense.date}","${expense.category}","${expense.description}",${expense.amount.toFixed(2)}\n`;
      });

      const fileName = `confeitaria-sara-export-${new Date().toISOString().split("T")[0]}.csv`;
      const filePath = `${FileSystem.documentDirectory}${fileName}`;

      if (!FileSystem.documentDirectory) {
        throw new Error("Diretório de documentos não disponível");
      }

      await FileSystem.writeAsStringAsync(filePath, csvContent);

      return filePath;
    } catch (error) {
      console.error("Erro ao exportar para CSV:", error);
      throw new Error("Não foi possível exportar os dados");
    }
  },
};
