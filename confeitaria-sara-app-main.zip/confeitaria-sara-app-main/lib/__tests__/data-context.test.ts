import { describe, it, expect, beforeEach, vi } from "vitest";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Order, OrderItem } from "@/types";

// Mock AsyncStorage
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
  },
}));

describe("Data Context Functions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Order Management", () => {
    it("should create a valid order with items", () => {
      const orderItem: OrderItem = {
        productId: "1",
        productName: "Brigadeiro",
        quantity: 10,
        price: 110,
        subtotal: 1100,
      };

      const order: Order = {
        id: "1",
        clientName: "João Silva",
        date: new Date().toISOString(),
        items: [orderItem],
        total: 1100,
        status: "open",
      };

      expect(order.clientName).toBe("João Silva");
      expect(order.items).toHaveLength(1);
      expect(order.total).toBe(1100);
      expect(order.status).toBe("open");
    });

    it("should calculate total correctly with multiple items", () => {
      const items: OrderItem[] = [
        {
          productId: "1",
          productName: "Brigadeiro",
          quantity: 10,
          price: 110,
          subtotal: 1100,
        },
        {
          productId: "2",
          productName: "Cajuzinho",
          quantity: 5,
          price: 110,
          subtotal: 550,
        },
      ];

      const total = items.reduce((sum, item) => sum + item.subtotal, 0);
      expect(total).toBe(1650);
    });

    it("should filter orders by month and year", () => {
      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();

      const order1: Order = {
        id: "1",
        clientName: "Cliente 1",
        date: new Date(currentYear, currentMonth, 15).toISOString(),
        items: [],
        total: 100,
        status: "open",
      };

      const order2: Order = {
        id: "2",
        clientName: "Cliente 2",
        date: new Date(currentYear, currentMonth - 1, 15).toISOString(),
        items: [],
        total: 200,
        status: "open",
      };

      const orders = [order1, order2];
      const filtered = orders.filter((order) => {
        const orderDate = new Date(order.date);
        return orderDate.getMonth() === currentMonth && orderDate.getFullYear() === currentYear;
      });

      expect(filtered).toHaveLength(1);
      expect(filtered[0].id).toBe("1");
    });
  });

  describe("Monthly Sales Data", () => {
    it("should calculate daily sales correctly", () => {
      const date = "2026-01-15";
      const dailySales = [
        { date, total: 1100, orderCount: 1 },
        { date: "2026-01-16", total: 550, orderCount: 1 },
      ];

      const totalSales = dailySales.reduce((sum, day) => sum + day.total, 0);
      expect(totalSales).toBe(1650);
    });

    it("should calculate product sales by quantity and total", () => {
      const productSales = [
        { productName: "Brigadeiro", quantity: 50, total: 5500 },
        { productName: "Cajuzinho", quantity: 30, total: 3300 },
      ];

      const topProduct = productSales.sort((a, b) => b.total - a.total)[0];
      expect(topProduct.productName).toBe("Brigadeiro");
      expect(topProduct.total).toBe(5500);
    });

    it("should calculate average ticket", () => {
      const totalSales = 1650;
      const totalOrders = 3;
      const averageTicket = totalSales / totalOrders;

      expect(averageTicket).toBeCloseTo(550, 0);
    });
  });

  describe("Product Management", () => {
    it("should have correct product prices", () => {
      const products = [
        { id: "1", name: "Brigadeiro", price: 110, category: "doces" as const },
        { id: "2", name: "Bombom Assado Salgado", price: 130, category: "salgados" as const },
      ];

      const doces = products.filter((p) => p.category === "doces");
      const salgados = products.filter((p) => p.category === "salgados");

      expect(doces).toHaveLength(1);
      expect(salgados).toHaveLength(1);
      expect(doces[0].price).toBe(110);
      expect(salgados[0].price).toBe(130);
    });
  });
});
