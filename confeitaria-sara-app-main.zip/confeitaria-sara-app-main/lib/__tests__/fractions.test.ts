import { describe, it, expect } from "vitest";

describe("Fraction Pricing System", () => {
  const PRICE_PER_HUNDRED = 110; // Brigadeiro

  const calculatePrice = (units: number, pricePerHundred: number) => {
    return (units / 100) * pricePerHundred;
  };

  const calculateTotalFromFractions = (fractions: number[], pricePerHundred: number) => {
    const totalUnits = fractions.reduce((sum, f) => sum + f, 0);
    return calculatePrice(totalUnits, pricePerHundred);
  };

  describe("Single Fraction Pricing", () => {
    it("should calculate price for 25 units (1/4)", () => {
      const price = calculatePrice(25, PRICE_PER_HUNDRED);
      expect(price).toBe(27.5);
    });

    it("should calculate price for 50 units (1/2)", () => {
      const price = calculatePrice(50, PRICE_PER_HUNDRED);
      expect(price).toBe(55);
    });

    it("should calculate price for 75 units (3/4)", () => {
      const price = calculatePrice(75, PRICE_PER_HUNDRED);
      expect(price).toBe(82.5);
    });

    it("should calculate price for 100 units (full)", () => {
      const price = calculatePrice(100, PRICE_PER_HUNDRED);
      expect(price).toBe(110);
    });

    it("should calculate price for 150 units (1.5x)", () => {
      const price = calculatePrice(150, PRICE_PER_HUNDRED);
      expect(price).toBe(165);
    });
  });

  describe("Multiple Fractions Combination", () => {
    it("should combine 50 + 50 = 100 units", () => {
      const fractions = [50, 50];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(110);
    });

    it("should combine 25 + 75 = 100 units", () => {
      const fractions = [25, 75];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(110);
    });

    it("should combine 50 + 50 + 50 = 150 units", () => {
      const fractions = [50, 50, 50];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(165);
    });

    it("should combine 25 + 25 + 50 = 100 units", () => {
      const fractions = [25, 25, 50];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(110);
    });

    it("should handle mixed fractions: 50 + 75 + 25 = 150 units", () => {
      const fractions = [50, 75, 25];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(165);
    });
  });

  describe("Multi-Product Order", () => {
    it("should calculate total for multiple products", () => {
      const brigadeiro = { fractions: [50, 50], price: 110 }; // 100 uni = R$ 110
      const cajuzinho = { fractions: [50], price: 110 }; // 50 uni = R$ 55
      const bombom = { fractions: [100], price: 170 }; // 100 uni = R$ 170

      const total =
        calculateTotalFromFractions(brigadeiro.fractions, brigadeiro.price) +
        calculateTotalFromFractions(cajuzinho.fractions, cajuzinho.price) +
        calculateTotalFromFractions(bombom.fractions, bombom.price);

      expect(total).toBe(335); // 110 + 55 + 170
    });

    it("should calculate order with mixed quantities", () => {
      // Cliente pede: 50 brigadeiro + 50 cajuzinho (totalizando 100)
      const brigadeiro = { fractions: [50], price: 110 }; // R$ 55
      const cajuzinho = { fractions: [50], price: 110 }; // R$ 55

      const total =
        calculateTotalFromFractions(brigadeiro.fractions, brigadeiro.price) +
        calculateTotalFromFractions(cajuzinho.fractions, cajuzinho.price);

      expect(total).toBe(110); // 55 + 55
    });
  });

  describe("Different Product Prices", () => {
    it("should handle different prices correctly", () => {
      const moranguinho = { fractions: [100], price: 160 }; // R$ 160 por 100
      const bombomSalgado = { fractions: [50], price: 130 }; // R$ 65 por 50

      const total =
        calculateTotalFromFractions(moranguinho.fractions, moranguinho.price) +
        calculateTotalFromFractions(bombomSalgado.fractions, bombomSalgado.price);

      expect(total).toBe(225); // 160 + 65
    });
  });

  describe("Edge Cases", () => {
    it("should handle empty fractions", () => {
      const fractions: number[] = [];
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(0);
    });

    it("should handle very small quantities", () => {
      const price = calculatePrice(1, PRICE_PER_HUNDRED);
      expect(price).toBeCloseTo(1.1, 2);
    });

    it("should handle large quantities", () => {
      const fractions = [100, 100, 100]; // 300 units
      const price = calculateTotalFromFractions(fractions, PRICE_PER_HUNDRED);
      expect(price).toBe(330); // 3 × R$ 110
    });
  });
});
