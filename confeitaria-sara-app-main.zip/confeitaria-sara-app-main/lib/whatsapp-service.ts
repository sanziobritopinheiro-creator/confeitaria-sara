import { Linking } from "react-native";
import { Order } from "@/types";

/**
 * Serviço de Integração com WhatsApp
 * Permite enviar mensagens de confirmação e lembretes via WhatsApp
 */

export const WhatsAppService = {
  /**
   * Formata número de telefone para o padrão internacional
   * Aceita: (33) 99931-5860, 33999315860, +5533999315860
   */
  formatPhoneNumber(phone: string): string {
    // Remove caracteres especiais
    let cleaned = phone.replace(/\D/g, "");

    // Se não tem código de país, adiciona 55 (Brasil)
    if (cleaned.length === 10 || cleaned.length === 11) {
      cleaned = "55" + cleaned;
    }

    return cleaned;
  },

  /**
   * Cria mensagem de confirmação de pedido
   */
  createOrderConfirmationMessage(order: Order): string {
    const itemsList = order.items
      .map((item) => `• ${item.productName} (${item.quantity} un) - R$ ${item.subtotal.toFixed(2)}`)
      .join("\n");

    const deliveryInfo = order.deliveryDate
      ? `\n📅 *Data de Entrega:* ${new Date(order.deliveryDate).toLocaleDateString("pt-BR")} às ${new Date(order.deliveryDate).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`
      : "";

    return `Olá ${order.clientName}! 👋\n\n✅ *Seu pedido foi confirmado!*\n\n*Itens:*\n${itemsList}\n\n💰 *Total:* R$ ${order.total.toFixed(2)}${deliveryInfo}\n\nObrigado por escolher a Confeitaria da Sara! 🍰`;
  },

  /**
   * Cria mensagem de lembrete de entrega
   */
  createDeliveryReminderMessage(order: Order): string {
    if (!order.deliveryDate) {
      return "";
    }

    const deliveryDate = new Date(order.deliveryDate);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const isTomorrow =
      deliveryDate.getDate() === tomorrow.getDate() &&
      deliveryDate.getMonth() === tomorrow.getMonth() &&
      deliveryDate.getFullYear() === tomorrow.getFullYear();

    const timeMessage = isTomorrow ? "amanhã" : "hoje";

    return `Olá ${order.clientName}! ⏰\n\n🎉 *Seu pedido será entregue ${timeMessage}!*\n\n🕐 *Horário:* ${deliveryDate.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}\n\n📍 *Local:* Rua Belo Horizonte, 157B - Jequitinhonha-MG\n\nFique atento! A Confeitaria da Sara está chegando! 🍰`;
  },

  /**
   * Abre WhatsApp com mensagem pré-formatada
   */
  async sendMessage(phoneNumber: string, message: string): Promise<boolean> {
    try {
      const formattedPhone = WhatsAppService.formatPhoneNumber(phoneNumber);

      // Codificar mensagem para URL
      const encodedMessage = encodeURIComponent(message);

      // URL do WhatsApp Web
      const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;

      // Verificar se WhatsApp está instalado
      const canOpen = await Linking.canOpenURL(whatsappUrl);

      if (canOpen) {
        await Linking.openURL(whatsappUrl);
        return true;
      } else {
        // Se WhatsApp não está instalado, tentar abrir WhatsApp Web
        await Linking.openURL(`https://web.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`);
        return true;
      }
    } catch (error) {
      console.error("Erro ao enviar mensagem WhatsApp:", error);
      return false;
    }
  },

  /**
   * Envia confirmação de pedido via WhatsApp
   */
  async sendOrderConfirmation(order: Order): Promise<boolean> {
    if (!order.clientPhone) {
      console.error("Número de WhatsApp não fornecido");
      return false;
    }

    const message = WhatsAppService.createOrderConfirmationMessage(order);
    return WhatsAppService.sendMessage(order.clientPhone, message);
  },

  /**
   * Envia lembrete de entrega via WhatsApp
   */
  async sendDeliveryReminder(order: Order): Promise<boolean> {
    if (!order.clientPhone) {
      console.error("Número de WhatsApp não fornecido");
      return false;
    }

    const message = WhatsAppService.createDeliveryReminderMessage(order);
    return WhatsAppService.sendMessage(order.clientPhone, message);
  },

  /**
   * Envia mensagem customizada
   */
  async sendCustomMessage(phoneNumber: string, message: string): Promise<boolean> {
    return WhatsAppService.sendMessage(phoneNumber, message);
  },

  /**
   * Valida se o número de telefone é válido
   */
  isValidPhoneNumber(phone: string): boolean {
    const cleaned = phone.replace(/\D/g, "");
    // Válido se tem 10 (sem código país), 11 (com DDD), ou 12-15 dígitos (com código país)
    return cleaned.length >= 10 && cleaned.length <= 15;
  },
};
