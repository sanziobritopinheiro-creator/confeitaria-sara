import * as Notifications from "expo-notifications";
import { Order } from "@/types";

/**
 * Serviço de Notificações Locais
 * Gerencia lembretes de entrega de pedidos
 */

// Configurar comportamento de notificações
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export const NotificationService = {
  /**
   * Agenda notificação de lembrete de entrega
   */
  async scheduleDeliveryReminder(order: Order): Promise<string | null> {
    try {
      if (!order.deliveryDate) {
        return null;
      }

      const deliveryDate = new Date(order.deliveryDate);
      const now = new Date();

      // Agendar notificação para 24 horas antes
      const reminderDate24h = new Date(deliveryDate.getTime() - 24 * 60 * 60 * 1000);

      if (reminderDate24h > now) {
        const notificationId = await Notifications.scheduleNotificationAsync({
          content: {
            title: "Lembrete de Entrega 📦",
            body: `Pedido de ${order.clientName} será entregue amanhã às ${new Date(order.deliveryDate).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`,
            data: { orderId: order.id, type: "delivery_reminder_24h" },
            sound: "default",
            badge: 1,
          },
          trigger: { type: "timeInterval" as any, seconds: Math.floor((reminderDate24h.getTime() - Date.now()) / 1000) },
        });

        return notificationId;
      }

      // Agendar notificação para 1 hora antes
      const reminderDate1h = new Date(deliveryDate.getTime() - 60 * 60 * 1000);

      if (reminderDate1h > now) {
        const notificationId = await Notifications.scheduleNotificationAsync({
          content: {
            title: "Entrega em 1 Hora ⏰",
            body: `Pedido de ${order.clientName} será entregue em 1 hora`,
            data: { orderId: order.id, type: "delivery_reminder_1h" },
            sound: "default",
            badge: 1,
          },
          trigger: { type: "timeInterval" as any, seconds: Math.floor((reminderDate1h.getTime() - Date.now()) / 1000) },
        });

        return notificationId;
      }

      return null;
    } catch (error) {
      console.error("Erro ao agendar notificação:", error);
      return null;
    }
  },

  /**
   * Agenda notificação de confirmação de pedido
   */
  async scheduleOrderConfirmation(order: Order): Promise<string | null> {
    try {
      const confirmationDate = new Date(Date.now() + 2000); // 2 segundos

      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: "Pedido Confirmado ✅",
          body: `Pedido de ${order.clientName} foi confirmado. Total: R$ ${order.total.toFixed(2)}`,
          data: { orderId: order.id, type: "order_confirmation" },
          sound: "default",
          badge: 1,
        },
        trigger: { type: "timeInterval" as any, seconds: 2 },
      });

      return notificationId;
    } catch (error) {
      console.error("Erro ao agendar confirmação:", error);
      return null;
    }
  },

  /**
   * Cancela uma notificação agendada
   */
  async cancelNotification(notificationId: string): Promise<void> {
    try {
      await Notifications.cancelScheduledNotificationAsync(notificationId);
    } catch (error) {
      console.error("Erro ao cancelar notificação:", error);
    }
  },

  /**
   * Cancela todas as notificações agendadas
   */
  async cancelAllNotifications(): Promise<void> {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
    } catch (error) {
      console.error("Erro ao cancelar todas as notificações:", error);
    }
  },

  /**
   * Obtém todas as notificações agendadas
   */
  async getAllScheduledNotifications(): Promise<Notifications.NotificationRequest[]> {
    try {
      return await Notifications.getAllScheduledNotificationsAsync();
    } catch (error) {
      console.error("Erro ao obter notificações agendadas:", error);
      return [];
    }
  },

  /**
   * Solicita permissão de notificações
   */
  async requestPermissions(): Promise<boolean> {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      return status === "granted";
    } catch (error) {
      console.error("Erro ao solicitar permissões:", error);
      return false;
    }
  },
};
