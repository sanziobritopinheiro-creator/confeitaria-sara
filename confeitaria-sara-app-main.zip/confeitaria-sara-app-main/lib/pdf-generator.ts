import * as FileSystem from "expo-file-system/legacy";
import { Order, Expense } from "@/types";

interface ReportData {
  month: number;
  year: number;
  orders: Order[];
  expenses: Expense[];
  businessName: string;
  businessPhone?: string;
  businessAddress?: string;
}

export async function generateMonthlyReportPDF(data: ReportData): Promise<{ filePath: string; fileName: string }> {
  const { month, year, orders, expenses, businessName, businessPhone, businessAddress } = data;

  // Calcular totais
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const profit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;

  // Agrupar pedidos por status
  const openOrders = orders.filter((o) => o.status === "open");
  const paidOrders = orders.filter((o) => o.status === "paid");
  const owingOrders = orders.filter((o) => o.status === "pending_payment");

  // Agrupar despesas por categoria
  const expensesByCategory = {
    ingredientes: expenses.filter((e) => e.category === "ingredientes"),
    embalagem: expenses.filter((e) => e.category === "embalagem"),
    transporte: expenses.filter((e) => e.category === "transporte"),
    outros: expenses.filter((e) => e.category === "outros"),
  };

  // Criar conteúdo HTML do PDF
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        * { margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #D946A6; padding-bottom: 20px; }
        .header h1 { color: #D946A6; font-size: 28px; margin-bottom: 5px; }
        .header p { color: #666; font-size: 12px; }
        .month-year { font-size: 18px; color: #666; margin-top: 10px; }
        .section { margin-bottom: 30px; }
        .section-title { background-color: #D946A6; color: white; padding: 10px 15px; font-size: 16px; font-weight: bold; margin-bottom: 15px; }
        .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
        .summary-card { background-color: #f5f5f5; padding: 15px; border-radius: 5px; border-left: 4px solid #D946A6; }
        .summary-card-label { font-size: 12px; color: #666; margin-bottom: 5px; }
        .summary-card-value { font-size: 24px; font-weight: bold; color: #D946A6; }
        .summary-card.negative .summary-card-value { color: #EF4444; }
        .summary-card.positive .summary-card-value { color: #22C55E; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background-color: #f0f0f0; padding: 10px; text-align: left; font-weight: bold; border-bottom: 2px solid #ddd; }
        td { padding: 8px 10px; border-bottom: 1px solid #eee; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .status-open { background-color: #FCD34D; color: #78350F; padding: 3px 8px; border-radius: 3px; font-size: 11px; }
        .status-paid { background-color: #DCFCE7; color: #166534; padding: 3px 8px; border-radius: 3px; font-size: 11px; }
        .status-owing { background-color: #FEE2E2; color: #991B1B; padding: 3px 8px; border-radius: 3px; font-size: 11px; }
        .footer { text-align: center; font-size: 11px; color: #999; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; }
        .business-info { font-size: 11px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <!-- Header -->
        <div class="header">
          <h1>${businessName}</h1>
          <div class="business-info">
            ${businessPhone ? `<p>📞 ${businessPhone}</p>` : ""}
            ${businessAddress ? `<p>📍 ${businessAddress}</p>` : ""}
          </div>
          <div class="month-year">
            Relatório de ${new Date(year, month).toLocaleString("pt-BR", { month: "long", year: "numeric" })}
          </div>
        </div>

        <!-- Resumo Financeiro -->
        <div class="section">
          <div class="section-title">📊 Resumo Financeiro</div>
          <div class="summary-grid">
            <div class="summary-card">
              <div class="summary-card-label">Receita Total</div>
              <div class="summary-card-value">R$ ${totalRevenue.toFixed(2)}</div>
            </div>
            <div class="summary-card">
              <div class="summary-card-label">Despesa Total</div>
              <div class="summary-card-value">R$ ${totalExpenses.toFixed(2)}</div>
            </div>
            <div class="summary-card ${profit >= 0 ? "positive" : "negative"}">
              <div class="summary-card-label">Lucro/Prejuízo</div>
              <div class="summary-card-value">R$ ${profit.toFixed(2)}</div>
            </div>
            <div class="summary-card">
              <div class="summary-card-label">Margem de Lucro</div>
              <div class="summary-card-value">${profitMargin.toFixed(1)}%</div>
            </div>
          </div>
        </div>

        <!-- Status de Pedidos -->
        <div class="section">
          <div class="section-title">📋 Status de Pedidos</div>
          <table>
            <tr>
              <th>Status</th>
              <th class="text-center">Quantidade</th>
              <th class="text-right">Valor Total</th>
            </tr>
            <tr>
              <td><span class="status-open">Pedido Aberto</span></td>
              <td class="text-center">${openOrders.length}</td>
              <td class="text-right">R$ ${openOrders.reduce((sum, o) => sum + o.total, 0).toFixed(2)}</td>
            </tr>
            <tr>
              <td><span class="status-paid">Concluído/Pago</span></td>
              <td class="text-center">${paidOrders.length}</td>
              <td class="text-right">R$ ${paidOrders.reduce((sum, o) => sum + o.total, 0).toFixed(2)}</td>
            </tr>
            <tr>
              <td><span class="status-owing">Concluído/Devendo</span></td>
              <td class="text-center">${owingOrders.length}</td>
              <td class="text-right">R$ ${owingOrders.reduce((sum, o) => sum + o.total, 0).toFixed(2)}</td>
            </tr>
          </table>
        </div>

        <!-- Despesas por Categoria -->
        <div class="section">
          <div class="section-title">💰 Despesas por Categoria</div>
          <table>
            <tr>
              <th>Categoria</th>
              <th class="text-center">Quantidade</th>
              <th class="text-right">Valor Total</th>
            </tr>
            ${
              Object.entries(expensesByCategory).map(([category, items]) => {
                const categoryLabel = {
                  ingredientes: "Ingredientes",
                  embalagem: "Embalagem",
                  transporte: "Transporte",
                  outros: "Outros",
                }[category];
                const total = items.reduce((sum, e) => sum + e.amount, 0);
                return `
                  <tr>
                    <td>${categoryLabel}</td>
                    <td class="text-center">${items.length}</td>
                    <td class="text-right">R$ ${total.toFixed(2)}</td>
                  </tr>
                `;
              }).join("")
            }
          </table>
        </div>

        <!-- Produtos Mais Vendidos -->
        ${
          orders.length > 0
            ? `
          <div class="section">
            <div class="section-title">🏆 Produtos Mais Vendidos</div>
            <table>
              <tr>
                <th>Produto</th>
                <th class="text-center">Quantidade</th>
                <th class="text-right">Receita</th>
              </tr>
              ${
                orders
                  .flatMap((o) => o.items)
                  .reduce(
                    (acc, item) => {
                      const existing = acc.find((i) => i.productId === item.productId);
                      if (existing) {
                        existing.quantity += item.quantity;
                        existing.revenue += item.price * item.quantity;
                      } else {
                        acc.push({
                          productId: item.productId,
                          productName: item.productName,
                          quantity: item.quantity,
                          revenue: item.price * item.quantity,
                        });
                      }
                      return acc;
                    },
                    [] as any[]
                  )
                  .sort((a, b) => b.revenue - a.revenue)
                  .slice(0, 10)
                  .map(
                    (item) => `
                  <tr>
                    <td>${item.productName}</td>
                    <td class="text-center">${item.quantity}</td>
                    <td class="text-right">R$ ${item.revenue.toFixed(2)}</td>
                  </tr>
                `
                  )
                  .join("")
              }
            </table>
          </div>
        `
            : ""
        }

        <!-- Footer -->
        <div class="footer">
          <p>Relatório gerado em ${new Date().toLocaleString("pt-BR")}</p>
          <p>Confeitaria da Sara - Sistema de Gestão de Pedidos</p>
        </div>
      </div>
    </body>
    </html>
  `;

  // Salvar HTML como arquivo
  const fileName = `relatorio_${businessName.replace(/\s+/g, "_")}_${month + 1}_${year}.html`;
  const filePath = `${FileSystem.documentDirectory || ""}${fileName}`;

  try {
    if (FileSystem.documentDirectory) {
      await FileSystem.writeAsStringAsync(filePath, htmlContent);
    } else {
      throw new Error("Diretório de documentos não disponível");
    }
    return { filePath, fileName };
  } catch (error) {
    console.error("Erro ao gerar relatório:", error);
    throw new Error("Não foi possível gerar o relatório");
  }
}
