/**
 * Tipos e interfaces para o aplicativo Confeitaria da Sara
 */

export interface Product {
  id: string;
  name: string;
  price: number;
  category: "doces" | "salgados";
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number; // quantidade em unidades (25, 50, 75, 100, 150, etc)
  price: number; // preço por 100 unidades
  subtotal: number; // preço total do item
  fractions?: number[]; // array de frações selecionadas (ex: [50, 50] = 100 unidades)
  cost?: number; // custo de produção por unidade (para cálculo de margem)
}

export interface Order {
  id: string;
  clientName: string;
  clientPhone?: string; // número WhatsApp do cliente (com DDD)
  date: string; // data/hora do pedido
  deliveryDate?: string; // data/hora de entrega desejada
  items: OrderItem[];
  total: number;
  status: "open" | "paid" | "pending_payment"; // Pedido Aberto | Concluído/Pago | Concluído/Devendo
  notes?: string;
  notificationSent?: boolean; // se notificação de entrega foi enviada
}

export interface DailySales {
  date: string;
  total: number;
  orderCount: number;
}

export interface MonthlySalesData {
  month: string;
  year: number;
  totalSales: number;
  totalOrders: number;
  dailySales: DailySales[];
  productSales: { productName: string; quantity: number; total: number }[];
}

export interface Expense {
  id: string;
  date: string; // data/hora do registro
  amount: number; // valor da despesa
  category: "ingredientes" | "embalagem" | "transporte" | "outros"; // categoria de despesa
  description: string; // descrição da despesa
  qrCodeData?: string; // dados do QR code do cupom (se disponível)
  notes?: string; // notas adicionais
}

export interface FinancialSummary {
  month: string;
  year: number;
  totalRevenue: number; // total de receitas (vendas)
  totalExpenses: number; // total de despesas
  profit: number; // lucro (receita - despesas)
  profitMargin: number; // margem de lucro em %
}
